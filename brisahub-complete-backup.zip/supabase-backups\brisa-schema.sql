


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE SCHEMA IF NOT EXISTS "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";


CREATE SCHEMA IF NOT EXISTS "public";


ALTER SCHEMA "public" OWNER TO "pg_database_owner";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE SCHEMA IF NOT EXISTS "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";


CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";


CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";


CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";


COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';



CREATE OR REPLACE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";


CREATE OR REPLACE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";


COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';



CREATE OR REPLACE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";


COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';



CREATE OR REPLACE FUNCTION "public"."_set_updated_at_premium"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."_set_updated_at_premium"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."allocate_wallet_withdrawal_sources"("p_user_id" "uuid", "p_withdrawal_transaction_id" "uuid", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_amount numeric(12,2);
  v_tx_user_id uuid;
  v_tx_status text;
  v_available_total numeric(12,2) := 0;
  v_remaining_to_allocate numeric(12,2);
  v_allocated_total numeric(12,2) := 0;
  v_item record;
  v_take numeric(12,2);
  v_allocation_id uuid;
  v_existing_allocations jsonb;
  v_result_allocations jsonb := '[]'::jsonb;
BEGIN
  IF p_user_id IS NULL OR p_withdrawal_transaction_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_required_argument');
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  v_amount := round(p_amount, 2);

  SELECT user_id, status
  INTO v_tx_user_id, v_tx_status
  FROM wallet_transactions
  WHERE id = p_withdrawal_transaction_id
    AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'withdrawal_not_found');
  END IF;

  IF v_tx_user_id IS DISTINCT FROM p_user_id THEN
    RETURN jsonb_build_object('ok', false, 'error', 'user_mismatch');
  END IF;

  IF v_tx_status NOT IN ('pending', 'processing') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_withdrawal_status', 'status', v_tx_status);
  END IF;

  SELECT jsonb_agg(
           jsonb_build_object(
             'allocation_id', a.id,
             'funding_source_id', a.funding_source_id,
             'source_wallet_transaction_id', a.source_wallet_transaction_id,
             'stripe_charge_id', a.stripe_charge_id,
             'allocated_amount', a.allocated_amount,
             'transfer_id', a.transfer_id
           )
           ORDER BY a.created_at, a.id
         )
  INTO v_existing_allocations
  FROM wallet_withdrawal_source_allocations a
  WHERE a.withdrawal_transaction_id = p_withdrawal_transaction_id
    AND a.restored_at IS NULL;

  IF v_existing_allocations IS NOT NULL THEN
    RETURN jsonb_build_object('ok', true, 'already_allocated', true, 'allocations', v_existing_allocations);
  END IF;

  FOR v_item IN
    SELECT remaining_amount
    FROM wallet_funding_sources
    WHERE current_owner_user_id = p_user_id
      AND status = 'available'
      AND stripe_charge_id IS NOT NULL
      AND remaining_amount > 0
    ORDER BY created_at, id
    FOR UPDATE
  LOOP
    v_available_total := round((v_available_total + v_item.remaining_amount)::numeric, 2);
  END LOOP;

  IF COALESCE(v_available_total, 0) < v_amount THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error', 'insufficient_funding_sources',
      'available', COALESCE(v_available_total, 0),
      'required', v_amount
    );
  END IF;

  v_remaining_to_allocate := v_amount;

  FOR v_item IN
    SELECT id, source_wallet_transaction_id, stripe_charge_id, remaining_amount
    FROM wallet_funding_sources
    WHERE current_owner_user_id = p_user_id
      AND status = 'available'
      AND stripe_charge_id IS NOT NULL
      AND remaining_amount > 0
    ORDER BY created_at, id
    FOR UPDATE
  LOOP
    EXIT WHEN v_remaining_to_allocate <= 0;

    v_take := round(LEAST(v_item.remaining_amount, v_remaining_to_allocate), 2);
    IF v_take <= 0 THEN
      CONTINUE;
    END IF;

    UPDATE wallet_funding_sources
    SET
      remaining_amount = round((remaining_amount - v_take)::numeric, 2),
      status = CASE
        WHEN round((remaining_amount - v_take)::numeric, 2) <= 0 THEN 'spent'
        ELSE 'available'
      END
    WHERE id = v_item.id;

    INSERT INTO wallet_withdrawal_source_allocations (
      withdrawal_transaction_id,
      funding_source_id,
      source_wallet_transaction_id,
      stripe_charge_id,
      allocated_amount
    )
    VALUES (
      p_withdrawal_transaction_id,
      v_item.id,
      v_item.source_wallet_transaction_id,
      v_item.stripe_charge_id,
      v_take
    )
    RETURNING id INTO v_allocation_id;

    v_result_allocations := v_result_allocations || jsonb_build_array(
      jsonb_build_object(
        'allocation_id', v_allocation_id,
        'funding_source_id', v_item.id,
        'source_wallet_transaction_id', v_item.source_wallet_transaction_id,
        'stripe_charge_id', v_item.stripe_charge_id,
        'allocated_amount', v_take
      )
    );

    v_allocated_total := round((v_allocated_total + v_take)::numeric, 2);
    v_remaining_to_allocate := round((v_remaining_to_allocate - v_take)::numeric, 2);
  END LOOP;

  IF v_allocated_total <> v_amount THEN
    RAISE EXCEPTION 'allocation_mismatch';
  END IF;

  RETURN jsonb_build_object('ok', true, 'already_allocated', false, 'allocations', v_result_allocations);
END;
$$;


ALTER FUNCTION "public"."allocate_wallet_withdrawal_sources"("p_user_id" "uuid", "p_withdrawal_transaction_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cancel_agency_withdrawal"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_amount  numeric(12,2);
  v_user_id uuid;
  v_status  text;
BEGIN
  SELECT user_id, amount, status
  INTO   v_user_id, v_amount, v_status
  FROM   wallet_transactions
  WHERE  id = p_tx_id AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  IF v_status NOT IN ('pending', 'processing', 'failed') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_cancellable', 'current_status', v_status);
  END IF;

  UPDATE wallet_transactions SET
    status       = 'rejected',
    admin_note   = p_note,
    processed_at = now(),
    processed_by = p_admin_id
  WHERE id = p_tx_id;

  UPDATE profiles
  SET wallet_balance = wallet_balance + v_amount
  WHERE id = v_user_id;

  RETURN jsonb_build_object('ok', true, 'amount_restored', v_amount);
END;
$$;


ALTER FUNCTION "public"."cancel_agency_withdrawal"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cancel_contract_safe"("p_contract_id" "uuid", "p_agency_id" "uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_status text;
  v_amount numeric(12,2);
  v_balance numeric(12,2);
  v_refund_tx_id uuid;
  v_item record;
BEGIN
  SELECT status, payment_amount
  INTO v_status, v_amount
  FROM contracts
  WHERE id = p_contract_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_found');
  END IF;

  IF v_status = 'paid' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'cannot_cancel_paid');
  END IF;

  IF v_status = 'cancelled' OR v_status = 'rejected' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'already_terminal', 'status', v_status);
  END IF;

  IF v_status = 'confirmed' AND v_amount > 0 AND p_agency_id IS NOT NULL THEN
    SELECT COALESCE(wallet_balance, 0)
    INTO v_balance
    FROM profiles
    WHERE id = p_agency_id
    FOR UPDATE;

    UPDATE profiles
    SET wallet_balance = round((v_balance + v_amount)::numeric, 2)
    WHERE id = p_agency_id;

    INSERT INTO wallet_transactions (user_id, type, amount, description)
    VALUES (
      p_agency_id,
      'refund',
      v_amount,
      'Estorno: contrato cancelado — fundos devolvidos'
    )
    RETURNING id INTO v_refund_tx_id;

    FOR v_item IN
      SELECT id, original_payer_user_id, stripe_charge_id, stripe_payment_intent_id, remaining_amount
      FROM wallet_funding_sources
      WHERE related_contract_id = p_contract_id
        AND source_type = 'escrow'
        AND status = 'reserved'
        AND remaining_amount > 0
      ORDER BY created_at, id
      FOR UPDATE
    LOOP
      INSERT INTO wallet_funding_sources (
        user_id,
        original_payer_user_id,
        current_owner_user_id,
        source_wallet_transaction_id,
        stripe_charge_id,
        stripe_payment_intent_id,
        source_type,
        original_amount,
        remaining_amount,
        status,
        upstream_funding_source_id
      )
      VALUES (
        p_agency_id,
        COALESCE(v_item.original_payer_user_id, p_agency_id),
        p_agency_id,
        v_refund_tx_id,
        v_item.stripe_charge_id,
        v_item.stripe_payment_intent_id,
        'wallet_deposit',
        v_item.remaining_amount,
        v_item.remaining_amount,
        'available',
        v_item.id
      );

      UPDATE wallet_funding_sources
      SET remaining_amount = 0, status = 'spent'
      WHERE id = v_item.id;
    END LOOP;
  END IF;

  UPDATE contracts
  SET status = 'cancelled'
  WHERE id = p_contract_id;

  RETURN jsonb_build_object('ok', true, 'status', 'cancelled');
END;
$$;


ALTER FUNCTION "public"."cancel_contract_safe"("p_contract_id" "uuid", "p_agency_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cancel_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_amount numeric(12,2);
  v_status text;
  v_note text := nullif(trim(coalesce(p_reason, '')), '');
BEGIN
  SELECT user_id, amount, status
  INTO v_user_id, v_amount, v_status
  FROM wallet_transactions
  WHERE id = p_transaction_id
    AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  IF v_status = 'cancelled' THEN
    RETURN jsonb_build_object('ok', true, 'status', 'cancelled', 'already_cancelled', true);
  END IF;

  IF v_status <> 'pending' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_pending', 'current_status', v_status);
  END IF;

  UPDATE profiles
  SET wallet_balance = round((coalesce(wallet_balance, 0) + v_amount)::numeric, 2)
  WHERE id = v_user_id;

  UPDATE wallet_transactions
  SET
    status = 'cancelled',
    provider_status = 'cancelled',
    processed_at = now(),
    admin_note = coalesce(v_note, admin_note)
  WHERE id = p_transaction_id;

  RETURN jsonb_build_object('ok', true, 'status', 'cancelled', 'amount_restored', v_amount);
END;
$$;


ALTER FUNCTION "public"."cancel_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."confirm_booking_escrow"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_status text;
  v_balance numeric(12,2);
  v_booking_id uuid;
  v_talent_id uuid;
  v_idem_key text := 'escrow_' || p_contract_id;
  v_tx_id uuid;
BEGIN
  IF EXISTS (
    SELECT 1 FROM wallet_transactions WHERE idempotency_key = v_idem_key
  ) THEN
    RETURN jsonb_build_object('ok', true, 'already_processed', true, 'status', 'confirmed');
  END IF;

  SELECT status, booking_id, talent_id
  INTO v_status, v_booking_id, v_talent_id
  FROM contracts
  WHERE id = p_contract_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_found');
  END IF;

  IF v_status != 'signed' THEN
    IF v_status = 'confirmed' THEN
      RETURN jsonb_build_object('ok', true, 'already_processed', true, 'status', 'confirmed');
    END IF;
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_signed', 'status', v_status);
  END IF;

  SELECT COALESCE(wallet_balance, 0)
  INTO v_balance
  FROM profiles
  WHERE id = p_agency_id
  FOR UPDATE;

  IF v_balance < p_amount THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error', 'insufficient_balance',
      'required', p_amount,
      'available', v_balance
    );
  END IF;

  UPDATE profiles
  SET wallet_balance = round((v_balance - p_amount)::numeric, 2)
  WHERE id = p_agency_id;

  INSERT INTO wallet_transactions (user_id, type, amount, description, idempotency_key)
  VALUES (
    p_agency_id,
    'escrow_lock',
    round(p_amount, 2),
    'Custodia: fundos retidos ate conclusao do servico',
    v_idem_key
  )
  RETURNING id INTO v_tx_id;

  UPDATE contracts
  SET
    status = 'confirmed',
    confirmed_at = now(),
    agency_signed_at = now(),
    deposit_paid_at = now()
  WHERE id = p_contract_id;

  IF v_booking_id IS NOT NULL THEN
    UPDATE bookings SET status = 'confirmed' WHERE id = v_booking_id;
  END IF;

  IF v_talent_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, message, link, is_read, idempotency_key)
    VALUES (
      v_talent_id, 'contract',
      'Agência confirmou o contrato e realizou o depósito',
      '/talent/contracts', false,
      'notif_escrow_talent_' || p_contract_id
    )
    ON CONFLICT (idempotency_key) DO NOTHING;
  END IF;

  INSERT INTO notifications (user_id, type, message, link, is_read, idempotency_key)
  VALUES (
    p_agency_id, 'booking',
    'Reserva confirmada — fundos em custódia',
    '/agency/finances', false,
    'notif_escrow_agency_' || p_contract_id
  )
  ON CONFLICT (idempotency_key) DO NOTHING;

  RETURN jsonb_build_object('ok', true, 'status', 'confirmed', 'transaction_id', v_tx_id);
END;
$$;


ALTER FUNCTION "public"."confirm_booking_escrow"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."confirm_contract_stripe_funding"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric, "p_payment_intent_id" "text", "p_charge_id" "text" DEFAULT NULL::"text", "p_checkout_session_id" "text" DEFAULT NULL::"text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_status text;
  v_contract_agency_id uuid;
  v_booking_id uuid;
  v_expected_amount numeric(12,2);
  v_amount numeric(12,2);
  v_existing_payment_intent text;
  v_idem_key text;
  v_tx_id uuid;
BEGIN
  IF p_contract_id IS NULL OR p_agency_id IS NULL OR p_payment_intent_id IS NULL OR trim(p_payment_intent_id) = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_required_argument');
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  v_amount := round(p_amount, 2);
  v_idem_key := 'stripe_contract_funding:' || p_contract_id || ':' || p_payment_intent_id;

  SELECT status, agency_id, booking_id, payment_amount, stripe_payment_intent_id
  INTO v_status, v_contract_agency_id, v_booking_id, v_expected_amount, v_existing_payment_intent
  FROM contracts
  WHERE id = p_contract_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_found');
  END IF;

  IF v_contract_agency_id IS DISTINCT FROM p_agency_id THEN
    RETURN jsonb_build_object('ok', false, 'error', 'agency_mismatch');
  END IF;

  IF abs(COALESCE(v_expected_amount, 0) - v_amount) > 0.01 THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error', 'amount_mismatch',
      'expected', v_expected_amount,
      'received', v_amount
    );
  END IF;

  IF v_status = 'confirmed' AND v_existing_payment_intent = p_payment_intent_id THEN
    RETURN jsonb_build_object('ok', true, 'already_processed', true, 'status', 'confirmed');
  END IF;

  IF v_status <> 'signed' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_signed', 'status', v_status);
  END IF;

  INSERT INTO wallet_transactions (
    user_id,
    type,
    amount,
    description,
    payment_id,
    reference_id,
    idempotency_key,
    provider,
    provider_status,
    status,
    processed_at,
    stripe_payment_intent_id,
    stripe_charge_id
  )
  VALUES (
    p_agency_id,
    'escrow_lock',
    v_amount,
    'Custodia via Stripe: fundos retidos ate conclusao do servico',
    p_payment_intent_id,
    p_contract_id::text,
    v_idem_key,
    'stripe',
    'paid',
    'paid',
    now(),
    p_payment_intent_id,
    NULLIF(p_charge_id, '')
  )
  ON CONFLICT DO NOTHING
  RETURNING id INTO v_tx_id;

  IF v_tx_id IS NOT NULL THEN
    INSERT INTO wallet_funding_sources (
      user_id,
      original_payer_user_id,
      current_owner_user_id,
      source_wallet_transaction_id,
      stripe_charge_id,
      stripe_payment_intent_id,
      source_type,
      original_amount,
      remaining_amount,
      status,
      related_contract_id
    )
    VALUES (
      p_agency_id,
      p_agency_id,
      p_agency_id,
      v_tx_id,
      NULLIF(p_charge_id, ''),
      p_payment_intent_id,
      'escrow',
      v_amount,
      v_amount,
      'reserved',
      p_contract_id
    );
  END IF;

  UPDATE contracts
  SET
    status = 'confirmed',
    payment_status = 'paid',
    confirmed_at = now(),
    agency_signed_at = now(),
    deposit_paid_at = now(),
    payment_provider = 'stripe',
    stripe_payment_intent_id = p_payment_intent_id,
    stripe_charge_id = NULLIF(p_charge_id, ''),
    stripe_checkout_session_id = NULLIF(p_checkout_session_id, '')
  WHERE id = p_contract_id;

  IF v_booking_id IS NOT NULL THEN
    UPDATE bookings
    SET status = 'confirmed'
    WHERE id = v_booking_id;
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'already_processed', v_tx_id IS NULL,
    'status', 'confirmed',
    'transaction_id', v_tx_id
  );
END;
$$;


ALTER FUNCTION "public"."confirm_contract_stripe_funding"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric, "p_payment_intent_id" "text", "p_charge_id" "text", "p_checkout_session_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."credit_referral_commission"("p_referrer_id" "uuid", "p_invite_id" "uuid", "p_contract_id" "uuid", "p_commission" numeric, "p_job_title" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_idem_key text := 'referral_commission:' || p_invite_id || ':' || p_contract_id;
  v_tx_id uuid;
BEGIN
  IF EXISTS (SELECT 1 FROM wallet_transactions WHERE idempotency_key = v_idem_key) THEN
    RETURN jsonb_build_object('ok', true, 'already_processed', true);
  END IF;

  UPDATE profiles
  SET wallet_balance = round((COALESCE(wallet_balance, 0) + p_commission)::numeric, 2)
  WHERE id = p_referrer_id;

  INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id, idempotency_key)
  VALUES (
    p_referrer_id,
    'referral_commission',
    p_commission,
    'Comissão de indicação (2%) - ' || COALESCE(p_job_title, 'trabalho'),
    p_contract_id::text,
    v_idem_key
  )
  RETURNING id INTO v_tx_id;

  UPDATE referral_invites
  SET
    status = 'commission_paid',
    commission_amount = p_commission,
    commission_paid_at = now(),
    paid_contract_id = p_contract_id,
    updated_at = now()
  WHERE id = p_invite_id;

  RETURN jsonb_build_object('ok', true, 'already_processed', false, 'wallet_balance_credited', true, 'transaction_id', v_tx_id);
END;
$$;


ALTER FUNCTION "public"."credit_referral_commission"("p_referrer_id" "uuid", "p_invite_id" "uuid", "p_contract_id" "uuid", "p_commission" numeric, "p_job_title" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."credit_stripe_wallet_deposit"("p_user_id" "uuid", "p_transaction_id" "uuid", "p_payment_id" "text", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_amount          numeric(12,2);
  v_tx_id           uuid;
  v_status          text;
  v_provider_status text;
BEGIN
  -- Validate inputs
  IF p_user_id IS NULL OR p_transaction_id IS NULL OR p_payment_id IS NULL OR trim(p_payment_id) = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_required_argument');
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  v_amount := round(p_amount::numeric, 2);

  -- Lock the existing pending transaction row, if any
  SELECT id, status, provider_status
  INTO v_tx_id, v_status, v_provider_status
  FROM wallet_transactions
  WHERE id      = p_transaction_id
    AND user_id = p_user_id
    AND type    = 'deposit'
  FOR UPDATE;

  IF v_tx_id IS NOT NULL THEN
    -- Already credited — return early without touching the balance
    IF v_status = 'paid' OR v_provider_status = 'paid' THEN
      RETURN jsonb_build_object(
        'ok',                   true,
        'already_processed',    true,
        'wallet_balance_credited', false,
        'transaction_id',       v_tx_id
      );
    END IF;

    -- Mark the transaction as paid
    UPDATE wallet_transactions
    SET
      status                = 'paid',
      provider              = 'stripe',
      provider_status       = 'paid',
      provider_transfer_id  = p_payment_id,
      payment_id            = p_payment_id,
      description           = 'Deposito via Stripe Checkout',
      processed_at          = now(),
      idempotency_key       = COALESCE(idempotency_key, 'stripe_wallet_deposit:' || p_payment_id)
    WHERE id = v_tx_id;

  ELSE
    -- No pending tx found — insert a synthetic paid record (handles retries where the pending row is missing)
    INSERT INTO wallet_transactions (
      user_id, type, amount, description,
      payment_id, provider, provider_status, provider_transfer_id,
      status, processed_at, idempotency_key
    )
    VALUES (
      p_user_id, 'deposit', v_amount, 'Deposito via Stripe Checkout',
      p_payment_id, 'stripe', 'paid', p_payment_id,
      'paid', now(), 'stripe_wallet_deposit:' || p_payment_id
    )
    ON CONFLICT DO NOTHING
    RETURNING id INTO v_tx_id;

    IF v_tx_id IS NULL THEN
      -- Conflict on idempotency_key means already inserted — look it up and return already_processed
      SELECT id INTO v_tx_id
      FROM wallet_transactions
      WHERE payment_id      = p_payment_id
         OR idempotency_key = 'stripe_wallet_deposit:' || p_payment_id
      LIMIT 1;

      RETURN jsonb_build_object(
        'ok',                   true,
        'already_processed',    true,
        'wallet_balance_credited', false,
        'transaction_id',       v_tx_id
      );
    END IF;
  END IF;

  -- Credit the wallet balance atomically
  UPDATE profiles
  SET wallet_balance = round((COALESCE(wallet_balance, 0) + v_amount)::numeric, 2)
  WHERE id = p_user_id;

  RETURN jsonb_build_object(
    'ok',                      true,
    'already_processed',       false,
    'wallet_balance_credited', true,
    'transaction_id',          v_tx_id,
    'amount',                  v_amount
  );
END;
$$;


ALTER FUNCTION "public"."credit_stripe_wallet_deposit"("p_user_id" "uuid", "p_transaction_id" "uuid", "p_payment_id" "text", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."credit_wallet_deposit"("p_user_id" "uuid", "p_payment_id" "text", "p_amount" numeric) RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_rows int;
begin
  -- Path 1: pending row already exists with payment_id; claim it once.
  update public.wallet_transactions
     set description = 'Depósito via PIX',
         amount = p_amount
   where payment_id = p_payment_id
     and user_id = p_user_id
     and coalesce(description, '') <> 'Depósito via PIX';

  get diagnostics v_rows = row_count;

  if v_rows = 0 then
    -- Path 2: no pending row; unique payment_id prevents double credit.
    insert into public.wallet_transactions (
      user_id,
      type,
      amount,
      description,
      payment_id
    )
    values (
      p_user_id,
      'deposit',
      p_amount,
      'Depósito via PIX',
      p_payment_id
    )
    on conflict (payment_id) do nothing;

    get diagnostics v_rows = row_count;

    if v_rows = 0 then
      return false;
    end if;
  end if;

  update public.profiles
     set wallet_balance = coalesce(wallet_balance, 0) + p_amount
   where id = p_user_id;

  return true;
end;
$$;


ALTER FUNCTION "public"."credit_wallet_deposit"("p_user_id" "uuid", "p_payment_id" "text", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fail_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text", "p_provider_status" "text" DEFAULT 'failed'::"text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_amount numeric(12,2);
  v_status text;
  v_note text := nullif(trim(coalesce(p_reason, '')), '');
  v_provider_status text := nullif(trim(coalesce(p_provider_status, '')), '');
BEGIN
  SELECT user_id, amount, status
  INTO v_user_id, v_amount, v_status
  FROM wallet_transactions
  WHERE id = p_transaction_id
    AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  IF v_status IN ('failed', 'cancelled') THEN
    RETURN jsonb_build_object('ok', true, 'status', v_status, 'already_finalized', true);
  END IF;

  IF v_status = 'paid' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'already_paid');
  END IF;

  IF v_status NOT IN ('pending', 'processing') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_pending', 'current_status', v_status);
  END IF;

  UPDATE profiles
  SET wallet_balance = round((coalesce(wallet_balance, 0) + v_amount)::numeric, 2)
  WHERE id = v_user_id;

  UPDATE wallet_transactions
  SET
    status = 'failed',
    provider_status = coalesce(v_provider_status, 'failed'),
    processed_at = now(),
    admin_note = coalesce(v_note, admin_note),
    failure_reason = coalesce(v_note, failure_reason),
    needs_admin_review = false
  WHERE id = p_transaction_id;

  RETURN jsonb_build_object('ok', true, 'status', 'failed', 'amount_restored', v_amount);
END;
$$;


ALTER FUNCTION "public"."fail_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text", "p_provider_status" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."finalize_contract_platform_revenue"("p_contract_id" "uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_item record;
  v_platform_amount numeric(12,2) := 0;
BEGIN
  FOR v_item IN
    SELECT id, user_id, original_payer_user_id, stripe_charge_id, stripe_payment_intent_id, source_wallet_transaction_id, remaining_amount
    FROM wallet_funding_sources
    WHERE related_contract_id = p_contract_id
      AND source_type = 'escrow'
      AND status = 'reserved'
      AND remaining_amount > 0
    ORDER BY created_at, id
    FOR UPDATE
  LOOP
    INSERT INTO wallet_funding_sources (
      user_id,
      original_payer_user_id,
      current_owner_user_id,
      source_wallet_transaction_id,
      stripe_charge_id,
      stripe_payment_intent_id,
      source_type,
      original_amount,
      remaining_amount,
      status,
      related_contract_id,
      upstream_funding_source_id
    )
    VALUES (
      COALESCE(v_item.user_id, v_item.original_payer_user_id),
      COALESCE(v_item.original_payer_user_id, v_item.user_id),
      NULL,
      v_item.source_wallet_transaction_id,
      v_item.stripe_charge_id,
      v_item.stripe_payment_intent_id,
      'platform_fee',
      v_item.remaining_amount,
      0,
      'platform_revenue',
      p_contract_id,
      v_item.id
    );

    UPDATE wallet_funding_sources
    SET remaining_amount = 0, status = 'spent'
    WHERE id = v_item.id;

    v_platform_amount := round((v_platform_amount + v_item.remaining_amount)::numeric, 2);
  END LOOP;

  RETURN jsonb_build_object('ok', true, 'platform_revenue_amount', v_platform_amount);
END;
$$;


ALTER FUNCTION "public"."finalize_contract_platform_revenue"("p_contract_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_auto_withdrawable_balance"("p_user_id" "uuid") RETURNS numeric
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_balance numeric(12,2);
BEGIN
  SELECT COALESCE(round(sum(remaining_amount)::numeric, 2), 0)
  INTO v_balance
  FROM wallet_funding_sources
  WHERE current_owner_user_id = p_user_id
    AND status = 'available'
    AND stripe_charge_id IS NOT NULL
    AND remaining_amount > 0;

  RETURN COALESCE(v_balance, 0);
END;
$$;


ALTER FUNCTION "public"."get_auto_withdrawable_balance"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."increment_wallet_balance"("p_user_id" "uuid", "p_amount" numeric) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
begin
  update public.profiles
  set wallet_balance = coalesce(wallet_balance, 0) + p_amount
  where id = p_user_id;
end;
$$;


ALTER FUNCTION "public"."increment_wallet_balance"("p_user_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mark_agency_withdrawal_paid"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_status text;
BEGIN
  SELECT status INTO v_status
  FROM   wallet_transactions
  WHERE  id = p_tx_id AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  -- Accept both pending (manual path) and processing (webhook path)
  IF v_status NOT IN ('pending', 'processing') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_pending', 'current_status', v_status);
  END IF;

  UPDATE wallet_transactions SET
    status       = 'paid',
    admin_note   = p_note,
    processed_at = now(),
    processed_by = p_admin_id
  WHERE id = p_tx_id;

  RETURN jsonb_build_object('ok', true);
END;
$$;


ALTER FUNCTION "public"."mark_agency_withdrawal_paid"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mark_wallet_withdrawal_paid"("p_transaction_id" "uuid", "p_provider" "text", "p_admin_note" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_status text;
  v_provider text := lower(trim(coalesce(p_provider, 'manual')));
  v_note text := nullif(trim(coalesce(p_admin_note, '')), '');
BEGIN
  SELECT status
  INTO v_status
  FROM wallet_transactions
  WHERE id = p_transaction_id
    AND type = 'withdrawal'
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  IF v_status = 'paid' THEN
    RETURN jsonb_build_object('ok', true, 'status', 'paid', 'already_paid', true);
  END IF;

  IF v_status NOT IN ('pending', 'processing', 'failed') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_pending', 'current_status', v_status);
  END IF;

  UPDATE wallet_transactions
  SET
    status = 'paid',
    provider = CASE WHEN v_provider = '' THEN 'manual' ELSE v_provider END,
    provider_status = 'paid',
    processed_at = now(),
    admin_note = coalesce(v_note, admin_note),
    failure_reason = null,
    needs_admin_review = false
  WHERE id = p_transaction_id;

  RETURN jsonb_build_object('ok', true, 'status', 'paid');
END;
$$;


ALTER FUNCTION "public"."mark_wallet_withdrawal_paid"("p_transaction_id" "uuid", "p_provider" "text", "p_admin_note" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_privilege_escalation"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- auth.uid() returns NULL for service-role requests (no JWT attached).
  -- Only block direct authenticated-user client calls.
  IF auth.uid() IS NOT NULL THEN
    IF NEW.role IS DISTINCT FROM OLD.role THEN
      RAISE EXCEPTION 'role change not permitted via client';
    END IF;
    IF NEW.wallet_balance IS DISTINCT FROM OLD.wallet_balance THEN
      RAISE EXCEPTION 'wallet_balance change not permitted via client';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."prevent_privilege_escalation"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."register_wallet_funding_source"("p_user_id" "uuid", "p_source_wallet_transaction_id" "uuid", "p_stripe_charge_id" "text", "p_stripe_payment_intent_id" "text", "p_source_type" "text", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_tx_user_id uuid;
  v_amount numeric(12,2);
  v_source_id uuid;
  v_source_type text := lower(trim(coalesce(p_source_type, 'wallet_deposit')));
BEGIN
  IF p_user_id IS NULL OR p_source_wallet_transaction_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_required_argument');
  END IF;

  IF p_stripe_charge_id IS NULL OR trim(p_stripe_charge_id) = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_stripe_charge_id');
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  IF v_source_type = 'deposit' THEN
    v_source_type := 'wallet_deposit';
  ELSIF v_source_type = 'referral_commission' THEN
    v_source_type := 'contract_payment';
  ELSIF v_source_type NOT IN ('wallet_deposit', 'contract_payment', 'escrow', 'platform_fee') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_source_type');
  END IF;

  v_amount := round(p_amount, 2);

  SELECT user_id
  INTO v_tx_user_id
  FROM wallet_transactions
  WHERE id = p_source_wallet_transaction_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'source_wallet_transaction_not_found');
  END IF;

  IF v_tx_user_id IS DISTINCT FROM p_user_id THEN
    RETURN jsonb_build_object('ok', false, 'error', 'user_mismatch');
  END IF;

  UPDATE wallet_transactions
  SET
    stripe_payment_intent_id = COALESCE(NULLIF(trim(coalesce(p_stripe_payment_intent_id, '')), ''), stripe_payment_intent_id),
    stripe_charge_id = NULLIF(trim(p_stripe_charge_id), '')
  WHERE id = p_source_wallet_transaction_id;

  SELECT id
  INTO v_source_id
  FROM wallet_funding_sources
  WHERE source_wallet_transaction_id = p_source_wallet_transaction_id
    AND current_owner_user_id = p_user_id
    AND source_type = v_source_type
  ORDER BY created_at DESC, id DESC
  LIMIT 1
  FOR UPDATE;

  IF v_source_id IS NOT NULL THEN
    UPDATE wallet_funding_sources
    SET
      stripe_charge_id = trim(p_stripe_charge_id),
      stripe_payment_intent_id = COALESCE(NULLIF(trim(coalesce(p_stripe_payment_intent_id, '')), ''), stripe_payment_intent_id),
      original_amount = v_amount,
      remaining_amount = CASE WHEN v_source_type = 'platform_fee' THEN 0 ELSE v_amount END,
      status = CASE WHEN v_source_type = 'platform_fee' THEN 'platform_revenue' ELSE 'available' END,
      original_payer_user_id = COALESCE(original_payer_user_id, p_user_id),
      current_owner_user_id = COALESCE(current_owner_user_id, p_user_id)
    WHERE id = v_source_id;

    RETURN jsonb_build_object(
      'ok', true,
      'funding_source_id', v_source_id,
      'amount', v_amount,
      'already_registered', true
    );
  END IF;

  INSERT INTO wallet_funding_sources (
    user_id,
    original_payer_user_id,
    current_owner_user_id,
    source_wallet_transaction_id,
    stripe_charge_id,
    stripe_payment_intent_id,
    source_type,
    original_amount,
    remaining_amount,
    status
  )
  VALUES (
    p_user_id,
    p_user_id,
    p_user_id,
    p_source_wallet_transaction_id,
    trim(p_stripe_charge_id),
    NULLIF(trim(coalesce(p_stripe_payment_intent_id, '')), ''),
    v_source_type,
    v_amount,
    CASE WHEN v_source_type = 'platform_fee' THEN 0 ELSE v_amount END,
    CASE WHEN v_source_type = 'platform_fee' THEN 'platform_revenue' ELSE 'available' END
  )
  RETURNING id INTO v_source_id;

  RETURN jsonb_build_object(
    'ok', true,
    'funding_source_id', v_source_id,
    'amount', v_amount
  );
END;
$$;


ALTER FUNCTION "public"."register_wallet_funding_source"("p_user_id" "uuid", "p_source_wallet_transaction_id" "uuid", "p_stripe_charge_id" "text", "p_stripe_payment_intent_id" "text", "p_source_type" "text", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."release_payment_payout"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_status text;
  v_talent_id uuid;
  v_booking_id uuid;
  v_idem_key text := 'payout_' || p_contract_id;
  v_tx_id uuid;
BEGIN
  IF EXISTS (SELECT 1 FROM wallet_transactions WHERE idempotency_key = v_idem_key) THEN
    RETURN jsonb_build_object('ok', true, 'already_processed', true, 'status', 'paid');
  END IF;

  SELECT status, talent_id, booking_id
  INTO v_status, v_talent_id, v_booking_id
  FROM contracts
  WHERE id = p_contract_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_found');
  END IF;

  IF v_status != 'confirmed' THEN
    IF v_status = 'paid' THEN
      RETURN jsonb_build_object('ok', true, 'already_processed', true, 'status', 'paid');
    END IF;
    RETURN jsonb_build_object('ok', false, 'error', 'contract_not_confirmed', 'status', v_status);
  END IF;

  IF p_amount > 0 AND v_talent_id IS NOT NULL THEN
    UPDATE profiles
    SET wallet_balance = round((COALESCE(wallet_balance, 0) + p_amount)::numeric, 2)
    WHERE id = v_talent_id;

    INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id, idempotency_key)
    VALUES (
      v_talent_id,
      'payout',
      p_amount,
      'Pagamento recebido pelo trabalho',
      p_contract_id::text,
      v_idem_key
    )
    RETURNING id INTO v_tx_id;
  END IF;

  UPDATE contracts
  SET
    status = 'paid',
    payment_status = 'paid',
    paid_at = now()
  WHERE id = p_contract_id;

  IF v_booking_id IS NOT NULL THEN
    UPDATE bookings SET status = 'paid' WHERE id = v_booking_id;
  END IF;

  IF v_talent_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, message, link, is_read, idempotency_key)
    VALUES (
      v_talent_id, 'payment', 'AgÃªncia liberou seu pagamento â€” a caminho!',
      '/talent/finances', false, 'notif_payout_talent_' || p_contract_id
    )
    ON CONFLICT (idempotency_key) DO NOTHING;
  END IF;

  RETURN jsonb_build_object('ok', true, 'status', 'paid', 'transaction_id', v_tx_id);
END;
$$;


ALTER FUNCTION "public"."release_payment_payout"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."request_agency_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_fee_rate" numeric DEFAULT 0) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_balance    numeric(12,2);
  v_fee        numeric(12,2);
  v_net        numeric(12,2);
  v_remaining numeric(12,2);
  v_idem_key   text;
  v_pix_type   text;
  v_pix_value  text;
BEGIN
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  IF p_amount < 1.00 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'below_minimum', 'minimum', 1.00);
  END IF;

  SELECT pix_key_type, pix_key_value
  INTO v_pix_type, v_pix_value
  FROM agencies
  WHERE id = p_user_id;

  IF v_pix_type IS NULL OR v_pix_value IS NULL OR trim(v_pix_value) = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'pix_not_configured');
  END IF;

  SELECT wallet_balance
  INTO v_balance
  FROM profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF v_balance IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'profile_not_found');
  END IF;

  IF v_balance < p_amount THEN
    RETURN jsonb_build_object('ok', false, 'error', 'insufficient_balance');
  END IF;

  v_fee := 0.00;
  v_net := p_amount;
  v_remaining := v_balance - p_amount;

  UPDATE profiles
  SET wallet_balance = v_remaining
  WHERE id = p_user_id;

  v_idem_key := 'withdraw_' || p_user_id::text || '_' || extract(epoch from clock_timestamp())::bigint::text;

  INSERT INTO wallet_transactions
    (user_id, type, amount, description, idempotency_key, status, fee_amount, net_amount)
  VALUES
    (p_user_id, 'withdrawal', p_amount, 'Saque solicitado', v_idem_key, 'pending', v_fee, v_net);

  RETURN jsonb_build_object(
    'ok', true,
    'amount', p_amount,
    'fee', v_fee,
    'net_amount', v_net,
    'remaining_balance', v_remaining
  );
END;
$$;


ALTER FUNCTION "public"."request_agency_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_fee_rate" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."request_talent_withdrawal"("p_user_id" "uuid", "p_amount" numeric) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_role       text;
  v_balance    numeric(12,2);
  v_amount     numeric(12,2);
  v_remaining  numeric(12,2);
  v_pix_type   text;
  v_pix_value  text;
  v_idem_key   text;
  v_tx_id      uuid;
BEGIN
  IF p_user_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_user');
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_amount');
  END IF;

  v_amount := round(p_amount, 2);

  SELECT role, wallet_balance
  INTO v_role, v_balance
  FROM profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF v_role IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'profile_not_found');
  END IF;

  IF v_role <> 'talent' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_talent');
  END IF;

  SELECT pix_key_type, pix_key_value
  INTO v_pix_type, v_pix_value
  FROM talent_profiles
  WHERE id = p_user_id;

  IF v_pix_type IS NULL OR v_pix_value IS NULL OR trim(v_pix_value) = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'pix_not_configured');
  END IF;

  IF COALESCE(v_balance, 0) < v_amount THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error', 'insufficient_balance',
      'available', COALESCE(v_balance, 0)
    );
  END IF;

  v_remaining := round((COALESCE(v_balance, 0) - v_amount)::numeric, 2);

  UPDATE profiles
  SET wallet_balance = v_remaining
  WHERE id = p_user_id;

  v_idem_key := 'talent_withdrawal:' || p_user_id::text || ':'
                || replace(gen_random_uuid()::text, '-', '');

  INSERT INTO wallet_transactions
    (user_id, type, amount, description, idempotency_key, status, fee_amount, net_amount)
  VALUES
    (p_user_id, 'withdrawal', v_amount, 'Saque solicitado por talento', v_idem_key, 'pending', 0, v_amount)
  RETURNING id INTO v_tx_id;

  RETURN jsonb_build_object(
    'ok', true,
    'tx_id', v_tx_id,
    'amount', v_amount,
    'net_amount', v_amount,
    'remaining_balance', v_remaining
  );
END;
$$;


ALTER FUNCTION "public"."request_talent_withdrawal"("p_user_id" "uuid", "p_amount" numeric) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."request_wallet_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_kind" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_role text;
  v_balance numeric(12,2);
  v_amount numeric(12,2);
  v_tx_id uuid;
  v_kind text := lower(trim(coalesce(p_kind, '')));
BEGIN
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'missing_user_id';
  END IF;

  IF v_kind NOT IN ('agency', 'talent') THEN
    RAISE EXCEPTION 'invalid_kind';
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'invalid_amount';
  END IF;

  v_amount := round(p_amount::numeric, 2);

  IF v_amount <= 0 THEN
    RAISE EXCEPTION 'invalid_amount';
  END IF;

  SELECT role, coalesce(wallet_balance, 0)
  INTO v_role, v_balance
  FROM profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'profile_not_found';
  END IF;

  IF v_role IS DISTINCT FROM v_kind THEN
    RAISE EXCEPTION 'role_mismatch';
  END IF;

  IF v_balance < v_amount THEN
    RAISE EXCEPTION 'insufficient_balance';
  END IF;

  UPDATE profiles
  SET wallet_balance = round((coalesce(wallet_balance, 0) - v_amount)::numeric, 2)
  WHERE id = p_user_id;

  INSERT INTO wallet_transactions (
    user_id,
    type,
    amount,
    description,
    status,
    provider,
    provider_status,
    fee_amount,
    net_amount,
    idempotency_key
  )
  VALUES (
    p_user_id,
    'withdrawal',
    v_amount,
    CASE
      WHEN v_kind = 'agency' THEN 'Saque solicitado pela agencia'
      ELSE 'Saque solicitado pelo talento'
    END,
    'pending',
    'manual',
    'pending',
    0,
    v_amount,
    'wallet_withdrawal:' || v_kind || ':' || p_user_id::text || ':' || replace(gen_random_uuid()::text, '-', '')
  )
  RETURNING id INTO v_tx_id;

  RETURN v_tx_id;
END;
$$;


ALTER FUNCTION "public"."request_wallet_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_kind" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."restore_wallet_withdrawal_sources"("p_withdrawal_transaction_id" "uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_row record;
  v_restored_amount numeric(12,2) := 0;
BEGIN
  IF p_withdrawal_transaction_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'missing_required_argument');
  END IF;

  FOR v_row IN
    SELECT id, funding_source_id, allocated_amount
    FROM wallet_withdrawal_source_allocations
    WHERE withdrawal_transaction_id = p_withdrawal_transaction_id
      AND restored_at IS NULL
    ORDER BY created_at, id
    FOR UPDATE
  LOOP
    UPDATE wallet_funding_sources
    SET
      remaining_amount = round((remaining_amount + v_row.allocated_amount)::numeric, 2),
      status = 'available'
    WHERE id = v_row.funding_source_id;

    UPDATE wallet_withdrawal_source_allocations
    SET restored_at = now()
    WHERE id = v_row.id;

    v_restored_amount := round((v_restored_amount + v_row.allocated_amount)::numeric, 2);
  END LOOP;

  RETURN jsonb_build_object(
    'ok', true,
    'restored_amount', v_restored_amount
  );
END;
$$;


ALTER FUNCTION "public"."restore_wallet_withdrawal_sources"("p_withdrawal_transaction_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_payments_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_payments_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."sync_agency_talent_history"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  IF NEW.talent_user_id IS NULL OR NEW.agency_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.status = 'paid' AND OLD.status IS DISTINCT FROM 'paid' THEN
    INSERT INTO agency_talent_history (agency_id, talent_id, jobs_count, jobs_completed, last_worked_at, last_job_status)
    VALUES (NEW.agency_id, NEW.talent_user_id, 1, 1, now(), 'paid')
    ON CONFLICT (agency_id, talent_id) DO UPDATE SET
      jobs_count      = agency_talent_history.jobs_count + 1,
      jobs_completed  = agency_talent_history.jobs_completed + 1,
      last_worked_at  = now(),
      last_job_status = 'paid';
    RETURN NEW;
  END IF;

  IF NEW.status = 'cancelled'
     AND NEW.cancelled_by = 'talent'
     AND (OLD.cancelled_by IS NULL OR OLD.cancelled_by != 'talent') THEN
    INSERT INTO agency_talent_history (agency_id, talent_id, jobs_count, jobs_cancelled, last_worked_at, last_job_status)
    VALUES (NEW.agency_id, NEW.talent_user_id, 0, 1, now(), 'cancelled')
    ON CONFLICT (agency_id, talent_id) DO UPDATE SET
      jobs_cancelled  = agency_talent_history.jobs_cancelled + 1,
      last_worked_at  = now(),
      last_job_status = 'cancelled';
    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."sync_agency_talent_history"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."sync_booking_on_contract_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  -- when contract becomes signed → move booking forward
  if new.status = 'signed' and old.status is distinct from 'signed' then
    update bookings
    set status = 'pending_payment'
    where id = new.booking_id
      and status = 'pending';
  end if;

  -- when contract becomes confirmed → keep booking confirmed
  if new.status = 'confirmed' and old.status is distinct from 'confirmed' then
    update bookings
    set status = 'confirmed'
    where id = new.booking_id;
  end if;

  -- when contract becomes paid → booking also paid
  if new.status = 'paid' and old.status is distinct from 'paid' then
    update bookings
    set status = 'paid'
    where id = new.booking_id;
  end if;

  -- when contract cancelled → booking cancelled
  if new.status = 'cancelled' then
    update bookings
    set status = 'cancelled'
    where id = new.booking_id;
  end if;

  return new;
end;
$$;


ALTER FUNCTION "public"."sync_booking_on_contract_update"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";


CREATE OR REPLACE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';



CREATE TABLE IF NOT EXISTS "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';



CREATE TABLE IF NOT EXISTS "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';



COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';



CREATE TABLE IF NOT EXISTS "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';



CREATE TABLE IF NOT EXISTS "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';



CREATE TABLE IF NOT EXISTS "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';



CREATE TABLE IF NOT EXISTS "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';



COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';



CREATE TABLE IF NOT EXISTS "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';



CREATE TABLE IF NOT EXISTS "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';



CREATE SEQUENCE IF NOT EXISTS "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";



CREATE TABLE IF NOT EXISTS "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';



CREATE TABLE IF NOT EXISTS "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';



CREATE TABLE IF NOT EXISTS "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';



CREATE TABLE IF NOT EXISTS "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';



COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';



COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';



COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';



CREATE TABLE IF NOT EXISTS "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';



CREATE TABLE IF NOT EXISTS "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';



COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';



CREATE TABLE IF NOT EXISTS "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";


COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';



COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';



CREATE TABLE IF NOT EXISTS "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";


CREATE TABLE IF NOT EXISTS "public"."admin_audit_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "admin_id" "uuid" NOT NULL,
    "action" "text" NOT NULL,
    "entity_type" "text" NOT NULL,
    "entity_id" "text",
    "before" "jsonb",
    "after" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."admin_audit_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."admin_notification_broadcasts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "admin_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "message" "text" NOT NULL,
    "audience" "text" NOT NULL,
    "target_user_id" "uuid",
    "link" "text",
    "sent_count" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."admin_notification_broadcasts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."agencies" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "name" "text",
    "avatar_url" "text",
    "subscription_status" "text" DEFAULT 'active'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "address" "text",
    "phone" "text",
    "email" "text",
    "website" "text",
    "description" "text",
    "company_name" "text",
    "contact_name" "text",
    "country" "text",
    "city" "text",
    "deleted_at" timestamp with time zone,
    "pix_key_type" "text",
    "pix_key_value" "text",
    "pix_holder_name" "text",
    "stripe_charges_enabled" boolean DEFAULT false NOT NULL,
    "stripe_payouts_enabled" boolean DEFAULT false NOT NULL,
    "stripe_details_submitted" boolean DEFAULT false NOT NULL,
    "stripe_transfers_active" boolean DEFAULT false NOT NULL,
    "stripe_connect_updated_at" timestamp with time zone,
    "stripe_account_id" "text",
    "state" "text"
);


ALTER TABLE "public"."agencies" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."agency_plans" (
    "user_id" "uuid" NOT NULL,
    "plan" "text" DEFAULT 'pro'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "agency_plans_plan_check" CHECK (("plan" = ANY (ARRAY['pro'::"text", 'basic'::"text"])))
);


ALTER TABLE "public"."agency_plans" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."agency_talent_history" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "agency_id" "uuid" NOT NULL,
    "talent_id" "uuid" NOT NULL,
    "jobs_count" integer DEFAULT 0,
    "last_worked_at" timestamp with time zone,
    "is_favorite" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "jobs_completed" integer DEFAULT 0 NOT NULL,
    "jobs_cancelled" integer DEFAULT 0 NOT NULL,
    "last_job_status" "text",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."agency_talent_history" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."applications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "job_id" "uuid",
    "talent_id" "uuid",
    "status" "text" DEFAULT 'pending'::"text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."applications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."asaas_webhook_events" (
    "id" "text" NOT NULL,
    "event_type" "text",
    "payload" "jsonb" NOT NULL,
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "event_id" "text"
);


ALTER TABLE "public"."asaas_webhook_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."backup_test_payments_20260501" (
    "id" "uuid",
    "provider" "text",
    "provider_payment_id" "text",
    "idempotency_key" "text",
    "booking_id" "uuid",
    "contract_id" "uuid",
    "agency_id" "uuid",
    "amount" numeric(12,2),
    "currency" "text",
    "status" "text",
    "raw_provider_payload" "jsonb",
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "public"."backup_test_payments_20260501" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."backup_test_wallet_transactions_20260501" (
    "id" "uuid",
    "user_id" "uuid",
    "amount" numeric,
    "type" "text",
    "created_at" timestamp with time zone,
    "description" "text",
    "idempotency_key" "text",
    "payment_id" "text",
    "reference_id" "text",
    "status" "text",
    "processed_at" timestamp with time zone,
    "processed_by" "uuid",
    "admin_note" "text",
    "fee_amount" numeric(12,2),
    "net_amount" numeric(12,2),
    "provider" "text",
    "provider_transfer_id" "text",
    "provider_status" "text",
    "provider_payout_id" "text",
    "failure_reason" "text",
    "needs_admin_review" boolean,
    "stripe_payment_intent_id" "text",
    "stripe_charge_id" "text",
    "asaas_payment_id" "text",
    "asaas_transfer_id" "text",
    "asaas_status" "text",
    "pix_key" "text",
    "pix_key_type" "text"
);


ALTER TABLE "public"."backup_test_wallet_transactions_20260501" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."bookings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "job_id" "uuid",
    "talent_id" "uuid",
    "status" "text" DEFAULT 'pending'::"text",
    "price" numeric,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "agency_id" "uuid",
    "talent_user_id" "uuid",
    "job_title" "text",
    "deleted_at" timestamp with time zone,
    "cancelled_by" "text",
    CONSTRAINT "bookings_status_valid" CHECK (("status" = ANY (ARRAY['pending'::"text", 'pending_payment'::"text", 'confirmed'::"text", 'paid'::"text", 'cancelled'::"text"]))),
    CONSTRAINT "valid_booking_status" CHECK (("status" = ANY (ARRAY['pending'::"text", 'pending_payment'::"text", 'confirmed'::"text", 'paid'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."bookings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."contracts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "booking_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text",
    "agency_signed_at" timestamp with time zone,
    "deposit_paid_at" timestamp with time zone,
    "paid_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "talent_id" "uuid",
    "agency_id" "uuid",
    "job_date" "date",
    "job_time" time without time zone,
    "location" "text",
    "job_description" "text",
    "payment_amount" numeric,
    "payment_method" "text",
    "additional_notes" "text",
    "signed_at" timestamp with time zone,
    "withdrawn_at" timestamp with time zone,
    "deleted_at" timestamp with time zone,
    "job_id" "uuid",
    "pix_payment_id" "text",
    "payment_status" "text" DEFAULT 'pending'::"text",
    "commission_amount" numeric(12,2),
    "net_amount" numeric(12,2),
    "contract_file_url" "text",
    "signed_contract_url" "text",
    "confirmed_at" timestamp with time zone,
    "stripe_payment_intent_id" "text",
    "stripe_charge_id" "text",
    "stripe_transfer_id" "text",
    "payment_provider" "text",
    "stripe_checkout_session_id" "text",
    CONSTRAINT "contracts_payment_provider_check" CHECK (("payment_provider" = ANY (ARRAY['efi'::"text", 'stripe'::"text", 'asaas'::"text"]))),
    CONSTRAINT "contracts_status_check" CHECK (("status" = ANY (ARRAY['sent'::"text", 'signed'::"text", 'rejected'::"text", 'confirmed'::"text", 'deposit_paid'::"text", 'paid'::"text", 'cancelled'::"text", 'withdrawn'::"text"])))
);


ALTER TABLE "public"."contracts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."job_invite_links" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "job_id" "uuid" NOT NULL,
    "workspace_id" "uuid",
    "created_by" "uuid" NOT NULL,
    "token" "text" NOT NULL,
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "expires_at" timestamp with time zone,
    "max_uses" integer,
    "use_count" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "job_invite_links_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'revoked'::"text", 'expired'::"text"])))
);


ALTER TABLE "public"."job_invite_links" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."job_invites" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "job_id" "uuid" NOT NULL,
    "talent_id" "uuid" NOT NULL,
    "agency_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."job_invites" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."jobs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "agency_id" "uuid",
    "title" "text",
    "description" "text",
    "job_date" "date",
    "talents_needed" integer,
    "status" "text" DEFAULT 'open'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "category" "text",
    "budget" numeric,
    "deadline" "date",
    "location" "text",
    "gender" "text",
    "age_min" integer,
    "age_max" integer,
    "number_of_talents_required" integer DEFAULT 1,
    "deleted_at" timestamp with time zone,
    "job_role" "text",
    "job_time" "text",
    "visibility" "text" DEFAULT 'public'::"text" NOT NULL,
    "application_requirements" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "workspace_id" "uuid",
    "created_by_user_id" "uuid",
    "invite_only" boolean DEFAULT false NOT NULL,
    CONSTRAINT "jobs_status_check" CHECK (("status" = ANY (ARRAY['open'::"text", 'closed'::"text", 'draft'::"text"]))),
    CONSTRAINT "jobs_visibility_check" CHECK (("visibility" = ANY (ARRAY['public'::"text", 'private'::"text", 'private_invite'::"text", 'workspace_only'::"text"])))
);


ALTER TABLE "public"."jobs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notifications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "type" "text",
    "message" "text",
    "link" "text",
    "is_read" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "idempotency_key" "text"
);

ALTER TABLE ONLY "public"."notifications" REPLICA IDENTITY FULL;


ALTER TABLE "public"."notifications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."payments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider" "text" DEFAULT 'mercadopago'::"text" NOT NULL,
    "provider_payment_id" "text" NOT NULL,
    "idempotency_key" "text" NOT NULL,
    "booking_id" "uuid",
    "contract_id" "uuid",
    "agency_id" "uuid",
    "amount" numeric(12,2) NOT NULL,
    "currency" "text" DEFAULT 'BRL'::"text" NOT NULL,
    "status" "text" NOT NULL,
    "raw_provider_payload" "jsonb",
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "payments_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'approved'::"text", 'rejected'::"text", 'cancelled'::"text", 'refunded'::"text", 'expired'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."payments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."plan_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "plan_key" "text" NOT NULL,
    "name" "text" NOT NULL,
    "price" numeric DEFAULT 0 NOT NULL,
    "commission_percent" numeric NOT NULL,
    "is_available" boolean DEFAULT true NOT NULL,
    "job_limit" integer,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "max_hires_per_job" integer,
    "included_agent_seats" integer,
    "extra_agent_seat_price" numeric
);


ALTER TABLE "public"."plan_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."plan_settings_history" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "plan_key" "text" NOT NULL,
    "changed_by" "uuid" NOT NULL,
    "changed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "old_price" numeric NOT NULL,
    "new_price" numeric NOT NULL,
    "old_commission_percent" numeric NOT NULL,
    "new_commission_percent" numeric NOT NULL,
    "old_is_available" boolean NOT NULL,
    "new_is_available" boolean NOT NULL,
    "old_job_limit" integer,
    "new_job_limit" integer,
    "old_included_agent_seats" integer,
    "new_included_agent_seats" integer,
    "old_extra_agent_seat_price" numeric,
    "new_extra_agent_seat_price" numeric
);


ALTER TABLE "public"."plan_settings_history" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."platform_balance" (
    "id" integer DEFAULT 1 NOT NULL,
    "balance" numeric DEFAULT 0 NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."platform_balance" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."platform_settings" (
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "description" "text",
    "updated_by" "uuid",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."platform_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."premium_agent_invites" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "workspace_id" "uuid" NOT NULL,
    "invited_email" "text" NOT NULL,
    "role" "text" DEFAULT 'agent'::"text" NOT NULL,
    "token" "text" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "accepted_by" "uuid",
    "accepted_at" timestamp with time zone,
    "created_by" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "spending_limit" numeric,
    CONSTRAINT "premium_agent_invites_role_check" CHECK (("role" = ANY (ARRAY['owner'::"text", 'agent'::"text"]))),
    CONSTRAINT "premium_agent_invites_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'accepted'::"text", 'expired'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."premium_agent_invites" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."premium_agent_wallet_transactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "workspace_id" "uuid" NOT NULL,
    "agent_user_id" "uuid" NOT NULL,
    "owner_user_id" "uuid" NOT NULL,
    "type" "text" NOT NULL,
    "amount" numeric(14,2) NOT NULL,
    "status" "text" DEFAULT 'completed'::"text" NOT NULL,
    "related_job_id" "uuid",
    "related_contract_id" "uuid",
    "note" "text",
    "created_by" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "reversed_at" timestamp with time zone,
    "metadata" "jsonb",
    CONSTRAINT "premium_agent_wallet_transactions_amount_check" CHECK (("amount" > (0)::numeric)),
    CONSTRAINT "premium_agent_wallet_transactions_status_check" CHECK (("status" = ANY (ARRAY['completed'::"text", 'reversed'::"text", 'pending'::"text"]))),
    CONSTRAINT "premium_agent_wallet_transactions_type_check" CHECK (("type" = ANY (ARRAY['allocation'::"text", 'allocation_reversal'::"text", 'job_commitment'::"text", 'job_release'::"text", 'refund'::"text", 'adjustment'::"text"])))
);


ALTER TABLE "public"."premium_agent_wallet_transactions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."premium_workspace_members" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "workspace_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text" DEFAULT 'agent'::"text" NOT NULL,
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "spending_limit" numeric,
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "removed_at" timestamp with time zone,
    CONSTRAINT "premium_workspace_members_role_check" CHECK (("role" = ANY (ARRAY['owner'::"text", 'agent'::"text"]))),
    CONSTRAINT "premium_workspace_members_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'invited'::"text", 'removed'::"text", 'suspended'::"text"])))
);


ALTER TABLE "public"."premium_workspace_members" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."premium_workspace_talents" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "workspace_id" "uuid" NOT NULL,
    "talent_user_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "source" "text" DEFAULT 'portal'::"text" NOT NULL,
    "invited_by" "uuid",
    "joined_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "removed_at" timestamp with time zone,
    CONSTRAINT "premium_workspace_talents_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'removed'::"text"])))
);


ALTER TABLE "public"."premium_workspace_talents" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."premium_workspaces" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "owner_user_id" "uuid" NOT NULL,
    "agency_id" "uuid",
    "name" "text" NOT NULL,
    "slug" "text",
    "logo_url" "text",
    "brand_primary_color" "text",
    "brand_accent_color" "text",
    "welcome_message" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "included_agent_seats" integer DEFAULT 2 NOT NULL,
    "extra_agent_seats" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "premium_workspaces_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'suspended'::"text", 'cancelled'::"text", 'deleted'::"text"])))
);


ALTER TABLE "public"."premium_workspaces" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "id" "uuid" NOT NULL,
    "role" "text",
    "full_name" "text",
    "avatar_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "onboarding_completed" boolean DEFAULT false,
    "wallet_balance" numeric DEFAULT 0,
    "plan" "text" DEFAULT 'free'::"text",
    "plan_status" "text" DEFAULT 'inactive'::"text",
    "plan_expires_at" timestamp with time zone,
    "is_frozen" boolean DEFAULT false NOT NULL,
    "mp_customer_id" "text",
    "asaas_customer_id" "text",
    "stripe_customer_id" "text",
    "stripe_subscription_id" "text",
    "stripe_subscription_status" "text",
    "stripe_price_id" "text",
    "asaas_subscription_id" "text",
    "asaas_subscription_status" "text",
    "cpf_cnpj" "text",
    "deleted_at" timestamp with time zone,
    "language_preference" "text" DEFAULT 'pt-BR'::"text"
);


ALTER TABLE "public"."profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."referral_invites" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "token" "text" DEFAULT "encode"("extensions"."gen_random_bytes"(24), 'hex'::"text") NOT NULL,
    "job_id" "uuid",
    "referrer_id" "uuid" NOT NULL,
    "referred_email" "text" NOT NULL,
    "referred_name" "text",
    "submission_id" "uuid",
    "referred_user_id" "uuid",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "commission_paid" numeric(12,2),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "commission_rate" numeric(5,4) DEFAULT 0.02 NOT NULL,
    "commission_amount" numeric(12,2),
    "signed_up_at" timestamp with time zone,
    "applied_at" timestamp with time zone,
    "hired_at" timestamp with time zone,
    "completed_at" timestamp with time zone,
    "commission_due_at" timestamp with time zone,
    "commission_paid_at" timestamp with time zone,
    "paid_contract_id" "uuid",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."referral_invites" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."saved_cards" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "mp_customer_id" "text" NOT NULL,
    "mp_card_id" "text" NOT NULL,
    "brand" "text",
    "last_four" "text",
    "holder_name" "text",
    "expiry_month" integer,
    "expiry_year" integer,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "holder_document_type" "text",
    "holder_document_number" "text",
    "issuer_id" "text"
);


ALTER TABLE "public"."saved_cards" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."stripe_events" (
    "id" "text" NOT NULL,
    "type" "text" NOT NULL,
    "livemode" boolean DEFAULT false NOT NULL,
    "processed_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."stripe_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."submissions" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "job_id" "uuid",
    "talent_user_id" "uuid",
    "talent_name" "text",
    "email" "text",
    "bio" "text",
    "referrer_id" "uuid",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "mode" "text",
    "photo_front_url" "text",
    "photo_left_url" "text",
    "photo_right_url" "text",
    "video_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "curriculum_url" "text",
    "portfolio_url" "text",
    CONSTRAINT "submissions_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'approved'::"text", 'rejected'::"text"])))
);


ALTER TABLE "public"."submissions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."support_conversations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "subject" "text" NOT NULL,
    "status" "text" DEFAULT 'open'::"text" NOT NULL,
    "priority" "text" DEFAULT 'normal'::"text" NOT NULL,
    "last_message_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "closed_at" timestamp with time zone,
    "archived_at" timestamp with time zone,
    "archived_by" "uuid",
    CONSTRAINT "support_conversations_priority_chk" CHECK (("priority" = ANY (ARRAY['low'::"text", 'normal'::"text", 'high'::"text", 'urgent'::"text"]))),
    CONSTRAINT "support_conversations_status_chk" CHECK (("status" = ANY (ARRAY['open'::"text", 'waiting_admin'::"text", 'waiting_user'::"text", 'closed'::"text"])))
);


ALTER TABLE "public"."support_conversations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."support_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "conversation_id" "uuid" NOT NULL,
    "sender_id" "uuid" NOT NULL,
    "sender_role" "text" NOT NULL,
    "message" "text" NOT NULL,
    "attachment_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "read_at" timestamp with time zone,
    CONSTRAINT "support_messages_sender_role_chk" CHECK (("sender_role" = ANY (ARRAY['user'::"text", 'admin'::"text"])))
);


ALTER TABLE "public"."support_messages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."talent_availability" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "talent_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "start_time" time without time zone,
    "end_time" time without time zone,
    "is_available" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."talent_availability" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."talent_profiles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "age" integer,
    "gender" "text",
    "phone" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "full_name" "text",
    "country" "text",
    "city" "text",
    "bio" "text",
    "categories" "text"[],
    "instagram" "text",
    "tiktok" "text",
    "youtube" "text",
    "x_handle" "text",
    "website" "text",
    "imdb" "text",
    "avatar_url" "text",
    "photo_front_url" "text",
    "photo_left_url" "text",
    "photo_right_url" "text",
    "username" "text",
    "deleted_at" timestamp with time zone,
    "ethnicity" "text",
    "eye_color" "text",
    "hair_color" "text",
    "skills" "text"[],
    "linkedin" "text",
    "twitter" "text",
    "pix_key_type" "text",
    "pix_key_value" "text",
    "cpf_or_id" "text",
    "main_role" "text",
    "stripe_account_id" "text",
    "pix_holder_name" "text",
    "stripe_charges_enabled" boolean DEFAULT false NOT NULL,
    "stripe_payouts_enabled" boolean DEFAULT false NOT NULL,
    "stripe_details_submitted" boolean DEFAULT false NOT NULL,
    "stripe_transfers_active" boolean DEFAULT false NOT NULL,
    "stripe_connect_updated_at" timestamp with time zone,
    "state" "text",
    "marketplace_visible" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."talent_profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."terms_acceptances" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "terms_version" "text" NOT NULL,
    "accepted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ip_address" "text",
    "user_agent" "text"
);


ALTER TABLE "public"."terms_acceptances" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_funding_sources" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "source_wallet_transaction_id" "uuid" NOT NULL,
    "stripe_charge_id" "text" NOT NULL,
    "stripe_payment_intent_id" "text",
    "source_type" "text" NOT NULL,
    "original_amount" numeric(12,2) NOT NULL,
    "remaining_amount" numeric(12,2) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "original_payer_user_id" "uuid",
    "current_owner_user_id" "uuid",
    "status" "text" DEFAULT 'available'::"text" NOT NULL,
    "related_contract_id" "uuid",
    "upstream_funding_source_id" "uuid"
);


ALTER TABLE "public"."wallet_funding_sources" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_transactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "amount" numeric,
    "type" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "description" "text",
    "idempotency_key" "text",
    "payment_id" "text",
    "reference_id" "text",
    "status" "text",
    "processed_at" timestamp with time zone,
    "processed_by" "uuid",
    "admin_note" "text",
    "fee_amount" numeric(12,2),
    "net_amount" numeric(12,2),
    "provider" "text",
    "provider_transfer_id" "text",
    "provider_status" "text",
    "provider_payout_id" "text",
    "failure_reason" "text",
    "needs_admin_review" boolean DEFAULT false NOT NULL,
    "stripe_payment_intent_id" "text",
    "stripe_charge_id" "text",
    "asaas_payment_id" "text",
    "asaas_transfer_id" "text",
    "asaas_status" "text",
    "pix_key" "text",
    "pix_key_type" "text",
    "invoice_url" "text"
);


ALTER TABLE "public"."wallet_transactions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_withdrawal_source_allocations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "withdrawal_transaction_id" "uuid" NOT NULL,
    "funding_source_id" "uuid" NOT NULL,
    "source_wallet_transaction_id" "uuid" NOT NULL,
    "stripe_charge_id" "text" NOT NULL,
    "allocated_amount" numeric(12,2) NOT NULL,
    "transfer_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "restored_at" timestamp with time zone
);


ALTER TABLE "public"."wallet_withdrawal_source_allocations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."webhook_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider" "text" DEFAULT 'mercadopago'::"text" NOT NULL,
    "event_id" "text" NOT NULL,
    "provider_event_id" "text" NOT NULL,
    "topic" "text",
    "raw_payload" "jsonb" NOT NULL,
    "received_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "processed" boolean DEFAULT false NOT NULL,
    "processed_at" timestamp with time zone,
    "error" "text"
);


ALTER TABLE "public"."webhook_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";


COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';



CREATE TABLE IF NOT EXISTS "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";


CREATE TABLE IF NOT EXISTS "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";


CREATE TABLE IF NOT EXISTS "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";


CREATE TABLE IF NOT EXISTS "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";


COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';



CREATE TABLE IF NOT EXISTS "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";


CREATE TABLE IF NOT EXISTS "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";


CREATE TABLE IF NOT EXISTS "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";


ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");



ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");



ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");



ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");



ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");



ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");



ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");



ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");



ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");



ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");



ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");



ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");



ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_audit_logs"
    ADD CONSTRAINT "admin_audit_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_notification_broadcasts"
    ADD CONSTRAINT "admin_notification_broadcasts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."agencies"
    ADD CONSTRAINT "agencies_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."agency_plans"
    ADD CONSTRAINT "agency_plans_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."agency_talent_history"
    ADD CONSTRAINT "agency_talent_history_agency_id_talent_id_key" UNIQUE ("agency_id", "talent_id");



ALTER TABLE ONLY "public"."agency_talent_history"
    ADD CONSTRAINT "agency_talent_history_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."applications"
    ADD CONSTRAINT "applications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."asaas_webhook_events"
    ADD CONSTRAINT "asaas_webhook_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."bookings"
    ADD CONSTRAINT "bookings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."job_invite_links"
    ADD CONSTRAINT "job_invite_links_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."job_invite_links"
    ADD CONSTRAINT "job_invite_links_token_key" UNIQUE ("token");



ALTER TABLE ONLY "public"."job_invites"
    ADD CONSTRAINT "job_invites_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."jobs"
    ADD CONSTRAINT "jobs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."payments"
    ADD CONSTRAINT "payments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."payments"
    ADD CONSTRAINT "payments_provider_id_uniq" UNIQUE ("provider", "provider_payment_id");



ALTER TABLE ONLY "public"."plan_settings_history"
    ADD CONSTRAINT "plan_settings_history_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."plan_settings"
    ADD CONSTRAINT "plan_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."plan_settings"
    ADD CONSTRAINT "plan_settings_plan_key_key" UNIQUE ("plan_key");



ALTER TABLE ONLY "public"."platform_balance"
    ADD CONSTRAINT "platform_balance_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."platform_settings"
    ADD CONSTRAINT "platform_settings_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."premium_agent_invites"
    ADD CONSTRAINT "premium_agent_invites_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."premium_agent_invites"
    ADD CONSTRAINT "premium_agent_invites_token_key" UNIQUE ("token");



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."premium_workspace_members"
    ADD CONSTRAINT "premium_workspace_members_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."premium_workspace_talents"
    ADD CONSTRAINT "premium_workspace_talents_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."premium_workspaces"
    ADD CONSTRAINT "premium_workspaces_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."premium_workspaces"
    ADD CONSTRAINT "premium_workspaces_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referral_invites"
    ADD CONSTRAINT "referral_invites_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."saved_cards"
    ADD CONSTRAINT "saved_cards_mp_card_id_key" UNIQUE ("mp_card_id");



ALTER TABLE ONLY "public"."saved_cards"
    ADD CONSTRAINT "saved_cards_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stripe_events"
    ADD CONSTRAINT "stripe_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."support_conversations"
    ADD CONSTRAINT "support_conversations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."support_messages"
    ADD CONSTRAINT "support_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."talent_availability"
    ADD CONSTRAINT "talent_availability_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."talent_availability"
    ADD CONSTRAINT "talent_availability_talent_id_date_key" UNIQUE ("talent_id", "date");



ALTER TABLE ONLY "public"."talent_profiles"
    ADD CONSTRAINT "talent_profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."talent_profiles"
    ADD CONSTRAINT "talent_profiles_username_key" UNIQUE ("username");



ALTER TABLE ONLY "public"."terms_acceptances"
    ADD CONSTRAINT "terms_acceptances_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_withdrawal_source_allocations"
    ADD CONSTRAINT "wallet_withdrawal_source_allo_withdrawal_transaction_id_fun_key" UNIQUE ("withdrawal_transaction_id", "funding_source_id");



ALTER TABLE ONLY "public"."wallet_withdrawal_source_allocations"
    ADD CONSTRAINT "wallet_withdrawal_source_allocations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."webhook_events"
    ADD CONSTRAINT "webhook_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."webhook_events"
    ADD CONSTRAINT "webhook_events_provider_event_uniq" UNIQUE ("provider", "provider_event_id");



ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");



ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");



CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");



CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");



CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");



CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");



CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");



CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");



CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");



CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");



CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");



CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);



CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");



COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';



CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");



CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");



CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");



CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");



CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");



CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);



CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);



CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);



CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");



CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");



CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");



CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");



CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);



CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);



CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);



CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");



CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");



CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");



CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");



CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");



CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");



CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");



CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");



CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");



CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);



CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");



CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);



CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");



CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");



CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);



CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");



CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");



CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));



CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");



CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));



CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");



CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");



CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");



CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);



COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';



CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));



CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");



CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");



CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");



CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");



CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");



CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");



CREATE INDEX "admin_audit_logs_admin_id_idx" ON "public"."admin_audit_logs" USING "btree" ("admin_id");



CREATE INDEX "admin_audit_logs_created_at_idx" ON "public"."admin_audit_logs" USING "btree" ("created_at" DESC);



CREATE INDEX "admin_audit_logs_entity_idx" ON "public"."admin_audit_logs" USING "btree" ("entity_type", "entity_id");



CREATE UNIQUE INDEX "agencies_stripe_account_id_uniq" ON "public"."agencies" USING "btree" ("stripe_account_id") WHERE ("stripe_account_id" IS NOT NULL);



CREATE UNIQUE INDEX "asaas_webhook_events_event_id_uniq" ON "public"."asaas_webhook_events" USING "btree" ("event_id") WHERE ("event_id" IS NOT NULL);



CREATE INDEX "contracts_agency_id_idx" ON "public"."contracts" USING "btree" ("agency_id");



CREATE INDEX "contracts_created_at_idx" ON "public"."contracts" USING "btree" ("created_at" DESC);



CREATE INDEX "contracts_deleted_at_idx" ON "public"."contracts" USING "btree" ("deleted_at");



CREATE INDEX "contracts_job_id_idx" ON "public"."contracts" USING "btree" ("job_id");



CREATE INDEX "contracts_status_idx" ON "public"."contracts" USING "btree" ("status");



CREATE INDEX "contracts_stripe_charge_idx" ON "public"."contracts" USING "btree" ("stripe_charge_id") WHERE ("stripe_charge_id" IS NOT NULL);



CREATE INDEX "contracts_stripe_checkout_session_idx" ON "public"."contracts" USING "btree" ("stripe_checkout_session_id") WHERE ("stripe_checkout_session_id" IS NOT NULL);



CREATE INDEX "contracts_stripe_payment_intent_idx" ON "public"."contracts" USING "btree" ("stripe_payment_intent_id") WHERE ("stripe_payment_intent_id" IS NOT NULL);



CREATE INDEX "contracts_talent_id_idx" ON "public"."contracts" USING "btree" ("talent_id");



CREATE INDEX "idx_admin_notification_broadcasts_admin_id" ON "public"."admin_notification_broadcasts" USING "btree" ("admin_id");



CREATE INDEX "idx_admin_notification_broadcasts_created_at" ON "public"."admin_notification_broadcasts" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_payments_agency_id" ON "public"."payments" USING "btree" ("agency_id") WHERE ("agency_id" IS NOT NULL);



CREATE INDEX "idx_payments_booking_id" ON "public"."payments" USING "btree" ("booking_id") WHERE ("booking_id" IS NOT NULL);



CREATE INDEX "idx_payments_contract_id" ON "public"."payments" USING "btree" ("contract_id") WHERE ("contract_id" IS NOT NULL);



CREATE INDEX "idx_payments_idempotency_key" ON "public"."payments" USING "btree" ("idempotency_key");



CREATE INDEX "idx_plan_settings_history_changed_at" ON "public"."plan_settings_history" USING "btree" ("changed_at" DESC);



CREATE INDEX "idx_plan_settings_history_plan_key" ON "public"."plan_settings_history" USING "btree" ("plan_key");



CREATE INDEX "idx_profiles_mp_customer_id" ON "public"."profiles" USING "btree" ("mp_customer_id");



CREATE INDEX "idx_support_conv_last_msg" ON "public"."support_conversations" USING "btree" ("last_message_at" DESC);



CREATE INDEX "idx_support_conv_status" ON "public"."support_conversations" USING "btree" ("status");



CREATE INDEX "idx_support_conv_user" ON "public"."support_conversations" USING "btree" ("user_id");



CREATE INDEX "idx_support_msg_conv" ON "public"."support_messages" USING "btree" ("conversation_id", "created_at");



CREATE INDEX "idx_webhook_events_event_id" ON "public"."webhook_events" USING "btree" ("event_id");



CREATE INDEX "idx_webhook_events_processed" ON "public"."webhook_events" USING "btree" ("processed");



CREATE INDEX "idx_webhook_events_received_at" ON "public"."webhook_events" USING "btree" ("received_at");



CREATE INDEX "job_invite_links_job_idx" ON "public"."job_invite_links" USING "btree" ("job_id");



CREATE INDEX "job_invite_links_token_idx" ON "public"."job_invite_links" USING "btree" ("token");



CREATE INDEX "job_invite_links_workspace_idx" ON "public"."job_invite_links" USING "btree" ("workspace_id") WHERE ("workspace_id" IS NOT NULL);



CREATE INDEX "job_invites_agency_id_idx" ON "public"."job_invites" USING "btree" ("agency_id");



CREATE INDEX "job_invites_job_id_idx" ON "public"."job_invites" USING "btree" ("job_id");



CREATE UNIQUE INDEX "job_invites_job_talent_uniq" ON "public"."job_invites" USING "btree" ("job_id", "talent_id");



CREATE INDEX "job_invites_talent_id_idx" ON "public"."job_invites" USING "btree" ("talent_id");



CREATE INDEX "jobs_workspace_id_idx" ON "public"."jobs" USING "btree" ("workspace_id") WHERE ("workspace_id" IS NOT NULL);



CREATE UNIQUE INDEX "notifications_idempotency_key_idx" ON "public"."notifications" USING "btree" ("idempotency_key");



CREATE INDEX "premium_agent_invites_email_idx" ON "public"."premium_agent_invites" USING "btree" ("invited_email");



CREATE INDEX "premium_agent_invites_token_idx" ON "public"."premium_agent_invites" USING "btree" ("token");



CREATE INDEX "premium_agent_invites_workspace_idx" ON "public"."premium_agent_invites" USING "btree" ("workspace_id");



CREATE INDEX "premium_agent_wallet_transactio_workspace_id_agent_user_id_idx1" ON "public"."premium_agent_wallet_transactions" USING "btree" ("workspace_id", "agent_user_id");



CREATE INDEX "premium_agent_wallet_transaction_workspace_id_agent_user_id_idx" ON "public"."premium_agent_wallet_transactions" USING "btree" ("workspace_id", "agent_user_id");



CREATE INDEX "premium_agent_wallet_transactions_related_job_id_idx" ON "public"."premium_agent_wallet_transactions" USING "btree" ("related_job_id") WHERE ("related_job_id" IS NOT NULL);



CREATE INDEX "premium_agent_wallet_transactions_related_job_id_idx1" ON "public"."premium_agent_wallet_transactions" USING "btree" ("related_job_id") WHERE ("related_job_id" IS NOT NULL);



CREATE INDEX "premium_agent_wallet_transactions_workspace_id_idx" ON "public"."premium_agent_wallet_transactions" USING "btree" ("workspace_id");



CREATE INDEX "premium_agent_wallet_transactions_workspace_id_idx1" ON "public"."premium_agent_wallet_transactions" USING "btree" ("workspace_id");



CREATE UNIQUE INDEX "premium_workspace_members_active_unique" ON "public"."premium_workspace_members" USING "btree" ("workspace_id", "user_id") WHERE ("removed_at" IS NULL);



CREATE INDEX "premium_workspace_members_user_idx" ON "public"."premium_workspace_members" USING "btree" ("user_id");



CREATE INDEX "premium_workspace_members_workspace_idx" ON "public"."premium_workspace_members" USING "btree" ("workspace_id");



CREATE UNIQUE INDEX "premium_workspace_talents_active_uidx" ON "public"."premium_workspace_talents" USING "btree" ("workspace_id", "talent_user_id") WHERE ("removed_at" IS NULL);



CREATE INDEX "premium_workspace_talents_talent_user_id_idx" ON "public"."premium_workspace_talents" USING "btree" ("talent_user_id");



CREATE INDEX "premium_workspace_talents_workspace_id_idx" ON "public"."premium_workspace_talents" USING "btree" ("workspace_id");



CREATE INDEX "premium_workspaces_agency_idx" ON "public"."premium_workspaces" USING "btree" ("agency_id") WHERE ("agency_id" IS NOT NULL);



CREATE UNIQUE INDEX "premium_workspaces_owner_active_unique" ON "public"."premium_workspaces" USING "btree" ("owner_user_id") WHERE (("deleted_at" IS NULL) AND ("status" <> ALL (ARRAY['cancelled'::"text", 'deleted'::"text"])));



CREATE INDEX "premium_workspaces_owner_idx" ON "public"."premium_workspaces" USING "btree" ("owner_user_id");



CREATE UNIQUE INDEX "profiles_stripe_customer_id_uniq" ON "public"."profiles" USING "btree" ("stripe_customer_id") WHERE ("stripe_customer_id" IS NOT NULL);



CREATE INDEX "profiles_stripe_subscription_id_idx" ON "public"."profiles" USING "btree" ("stripe_subscription_id") WHERE ("stripe_subscription_id" IS NOT NULL);



CREATE INDEX "referral_invites_job_email_idx" ON "public"."referral_invites" USING "btree" ("job_id", "lower"("referred_email")) WHERE (("job_id" IS NOT NULL) AND ("referred_email" IS NOT NULL));



CREATE INDEX "referral_invites_job_user_idx" ON "public"."referral_invites" USING "btree" ("job_id", "referred_user_id") WHERE (("job_id" IS NOT NULL) AND ("referred_user_id" IS NOT NULL));



CREATE INDEX "referral_invites_token_job_idx" ON "public"."referral_invites" USING "btree" ("token", "job_id");



CREATE UNIQUE INDEX "referral_invites_token_key" ON "public"."referral_invites" USING "btree" ("token");



CREATE INDEX "saved_cards_user_id_idx" ON "public"."saved_cards" USING "btree" ("user_id");



CREATE INDEX "support_conversations_archived_at_idx" ON "public"."support_conversations" USING "btree" ("archived_at") WHERE ("archived_at" IS NOT NULL);



CREATE INDEX "talent_availability_date_idx" ON "public"."talent_availability" USING "btree" ("date");



CREATE INDEX "talent_availability_talent_id_idx" ON "public"."talent_availability" USING "btree" ("talent_id");



CREATE INDEX "talent_profiles_age_idx" ON "public"."talent_profiles" USING "btree" ("age");



CREATE INDEX "talent_profiles_deleted_at_idx" ON "public"."talent_profiles" USING "btree" ("deleted_at");



CREATE INDEX "talent_profiles_gender_idx" ON "public"."talent_profiles" USING "btree" ("gender");



CREATE INDEX "talent_profiles_instagram_idx" ON "public"."talent_profiles" USING "btree" ("instagram");



CREATE INDEX "talent_profiles_marketplace_visible_idx" ON "public"."talent_profiles" USING "btree" ("marketplace_visible") WHERE ("deleted_at" IS NULL);



CREATE UNIQUE INDEX "talent_profiles_stripe_account_id_uniq" ON "public"."talent_profiles" USING "btree" ("stripe_account_id") WHERE ("stripe_account_id" IS NOT NULL);



CREATE INDEX "terms_acceptances_terms_version_idx" ON "public"."terms_acceptances" USING "btree" ("terms_version");



CREATE INDEX "terms_acceptances_user_id_idx" ON "public"."terms_acceptances" USING "btree" ("user_id");



CREATE UNIQUE INDEX "terms_acceptances_user_version_uniq" ON "public"."terms_acceptances" USING "btree" ("user_id", "terms_version");



CREATE INDEX "wallet_funding_sources_charge_idx" ON "public"."wallet_funding_sources" USING "btree" ("stripe_charge_id");



CREATE INDEX "wallet_funding_sources_contract_idx" ON "public"."wallet_funding_sources" USING "btree" ("related_contract_id", "status", "created_at", "id");



CREATE INDEX "wallet_funding_sources_owner_status_idx" ON "public"."wallet_funding_sources" USING "btree" ("current_owner_user_id", "status", "created_at", "id");



CREATE INDEX "wallet_funding_sources_upstream_idx" ON "public"."wallet_funding_sources" USING "btree" ("upstream_funding_source_id");



CREATE INDEX "wallet_funding_sources_user_created_idx" ON "public"."wallet_funding_sources" USING "btree" ("user_id", "created_at", "id");



CREATE UNIQUE INDEX "wallet_idempotency_key_idx" ON "public"."wallet_transactions" USING "btree" ("idempotency_key") WHERE ("idempotency_key" IS NOT NULL);



CREATE INDEX "wallet_transactions_asaas_payment_id_idx" ON "public"."wallet_transactions" USING "btree" ("asaas_payment_id");



CREATE UNIQUE INDEX "wallet_transactions_asaas_payment_id_uniq" ON "public"."wallet_transactions" USING "btree" ("asaas_payment_id") WHERE ("asaas_payment_id" IS NOT NULL);



CREATE INDEX "wallet_transactions_asaas_transfer_id_idx" ON "public"."wallet_transactions" USING "btree" ("asaas_transfer_id");



CREATE UNIQUE INDEX "wallet_transactions_idempotency_key_idx" ON "public"."wallet_transactions" USING "btree" ("idempotency_key");



CREATE UNIQUE INDEX "wallet_transactions_payment_id_unique_idx" ON "public"."wallet_transactions" USING "btree" ("payment_id");



CREATE UNIQUE INDEX "wallet_transactions_provider_transfer_id_uniq" ON "public"."wallet_transactions" USING "btree" ("provider_transfer_id") WHERE ("provider_transfer_id" IS NOT NULL);



CREATE INDEX "wallet_withdrawal_allocations_withdrawal_idx" ON "public"."wallet_withdrawal_source_allocations" USING "btree" ("withdrawal_transaction_id", "created_at", "id");



CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");



CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");



CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);



CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");



CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");



CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");



CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");



CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");



CREATE OR REPLACE TRIGGER "trg_payments_updated_at" BEFORE UPDATE ON "public"."payments" FOR EACH ROW EXECUTE FUNCTION "public"."set_payments_updated_at"();



CREATE OR REPLACE TRIGGER "trg_premium_workspace_members_updated_at" BEFORE UPDATE ON "public"."premium_workspace_members" FOR EACH ROW EXECUTE FUNCTION "public"."_set_updated_at_premium"();



CREATE OR REPLACE TRIGGER "trg_premium_workspaces_updated_at" BEFORE UPDATE ON "public"."premium_workspaces" FOR EACH ROW EXECUTE FUNCTION "public"."_set_updated_at_premium"();



CREATE OR REPLACE TRIGGER "trg_prevent_privilege_escalation" BEFORE UPDATE ON "public"."profiles" FOR EACH ROW EXECUTE FUNCTION "public"."prevent_privilege_escalation"();



CREATE OR REPLACE TRIGGER "trg_sync_agency_talent_history" AFTER UPDATE ON "public"."bookings" FOR EACH ROW WHEN ((("old"."status" IS DISTINCT FROM "new"."status") OR ("old"."cancelled_by" IS DISTINCT FROM "new"."cancelled_by"))) EXECUTE FUNCTION "public"."sync_agency_talent_history"();



CREATE OR REPLACE TRIGGER "trg_sync_booking_on_contract_update" AFTER UPDATE ON "public"."contracts" FOR EACH ROW EXECUTE FUNCTION "public"."sync_booking_on_contract_update"();



CREATE OR REPLACE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();



CREATE OR REPLACE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();



CREATE OR REPLACE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();



CREATE OR REPLACE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();



ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."agencies"
    ADD CONSTRAINT "agencies_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."agency_plans"
    ADD CONSTRAINT "agency_plans_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."applications"
    ADD CONSTRAINT "applications_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."applications"
    ADD CONSTRAINT "applications_talent_id_fkey" FOREIGN KEY ("talent_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."bookings"
    ADD CONSTRAINT "bookings_agency_id_fkey" FOREIGN KEY ("agency_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."bookings"
    ADD CONSTRAINT "bookings_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."bookings"
    ADD CONSTRAINT "bookings_talent_id_fkey" FOREIGN KEY ("talent_id") REFERENCES "public"."talent_profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."bookings"
    ADD CONSTRAINT "bookings_talent_user_id_fkey" FOREIGN KEY ("talent_user_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_agency_id_fkey" FOREIGN KEY ("agency_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_booking_fk" FOREIGN KEY ("booking_id") REFERENCES "public"."bookings"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "public"."bookings"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."contracts"
    ADD CONSTRAINT "contracts_talent_id_fkey" FOREIGN KEY ("talent_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."job_invite_links"
    ADD CONSTRAINT "job_invite_links_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."job_invite_links"
    ADD CONSTRAINT "job_invite_links_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."job_invite_links"
    ADD CONSTRAINT "job_invite_links_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."job_invites"
    ADD CONSTRAINT "job_invites_agency_id_fkey" FOREIGN KEY ("agency_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."job_invites"
    ADD CONSTRAINT "job_invites_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."job_invites"
    ADD CONSTRAINT "job_invites_talent_id_fkey" FOREIGN KEY ("talent_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."jobs"
    ADD CONSTRAINT "jobs_agency_id_fkey" FOREIGN KEY ("agency_id") REFERENCES "public"."agencies"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."jobs"
    ADD CONSTRAINT "jobs_created_by_user_id_fkey" FOREIGN KEY ("created_by_user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."jobs"
    ADD CONSTRAINT "jobs_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id");



ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."payments"
    ADD CONSTRAINT "payments_agency_id_fkey" FOREIGN KEY ("agency_id") REFERENCES "public"."profiles"("id");



ALTER TABLE ONLY "public"."payments"
    ADD CONSTRAINT "payments_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "public"."bookings"("id");



ALTER TABLE ONLY "public"."payments"
    ADD CONSTRAINT "payments_contract_id_fkey" FOREIGN KEY ("contract_id") REFERENCES "public"."contracts"("id");



ALTER TABLE ONLY "public"."premium_agent_invites"
    ADD CONSTRAINT "premium_agent_invites_accepted_by_fkey" FOREIGN KEY ("accepted_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_agent_invites"
    ADD CONSTRAINT "premium_agent_invites_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_agent_invites"
    ADD CONSTRAINT "premium_agent_invites_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_agent_user_id_fkey" FOREIGN KEY ("agent_user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_owner_user_id_fkey" FOREIGN KEY ("owner_user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_related_contract_id_fkey" FOREIGN KEY ("related_contract_id") REFERENCES "public"."contracts"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_related_job_id_fkey" FOREIGN KEY ("related_job_id") REFERENCES "public"."jobs"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."premium_agent_wallet_transactions"
    ADD CONSTRAINT "premium_agent_wallet_transactions_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."premium_workspace_members"
    ADD CONSTRAINT "premium_workspace_members_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_workspace_members"
    ADD CONSTRAINT "premium_workspace_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."premium_workspace_members"
    ADD CONSTRAINT "premium_workspace_members_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."premium_workspace_talents"
    ADD CONSTRAINT "premium_workspace_talents_invited_by_fkey" FOREIGN KEY ("invited_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_workspace_talents"
    ADD CONSTRAINT "premium_workspace_talents_talent_user_id_fkey" FOREIGN KEY ("talent_user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."premium_workspace_talents"
    ADD CONSTRAINT "premium_workspace_talents_workspace_id_fkey" FOREIGN KEY ("workspace_id") REFERENCES "public"."premium_workspaces"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."premium_workspaces"
    ADD CONSTRAINT "premium_workspaces_owner_user_id_fkey" FOREIGN KEY ("owner_user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."saved_cards"
    ADD CONSTRAINT "saved_cards_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_talent_user_id_fkey" FOREIGN KEY ("talent_user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."support_conversations"
    ADD CONSTRAINT "support_conversations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."support_messages"
    ADD CONSTRAINT "support_messages_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "public"."support_conversations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."support_messages"
    ADD CONSTRAINT "support_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."talent_availability"
    ADD CONSTRAINT "talent_availability_talent_id_fkey" FOREIGN KEY ("talent_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."talent_profiles"
    ADD CONSTRAINT "talent_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."terms_acceptances"
    ADD CONSTRAINT "terms_acceptances_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_current_owner_user_id_fkey" FOREIGN KEY ("current_owner_user_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_original_payer_user_id_fkey" FOREIGN KEY ("original_payer_user_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_related_contract_id_fkey" FOREIGN KEY ("related_contract_id") REFERENCES "public"."contracts"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_source_wallet_transaction_id_fkey" FOREIGN KEY ("source_wallet_transaction_id") REFERENCES "public"."wallet_transactions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_upstream_funding_source_id_fkey" FOREIGN KEY ("upstream_funding_source_id") REFERENCES "public"."wallet_funding_sources"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_funding_sources"
    ADD CONSTRAINT "wallet_funding_sources_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_processed_by_fkey" FOREIGN KEY ("processed_by") REFERENCES "public"."profiles"("id");



ALTER TABLE ONLY "public"."wallet_withdrawal_source_allocations"
    ADD CONSTRAINT "wallet_withdrawal_source_allo_source_wallet_transaction_id_fkey" FOREIGN KEY ("source_wallet_transaction_id") REFERENCES "public"."wallet_transactions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_withdrawal_source_allocations"
    ADD CONSTRAINT "wallet_withdrawal_source_allocat_withdrawal_transaction_id_fkey" FOREIGN KEY ("withdrawal_transaction_id") REFERENCES "public"."wallet_transactions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_withdrawal_source_allocations"
    ADD CONSTRAINT "wallet_withdrawal_source_allocations_funding_source_id_fkey" FOREIGN KEY ("funding_source_id") REFERENCES "public"."wallet_funding_sources"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");



ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");



ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");



ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");



ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "Service role can do everything on profiles" ON "public"."profiles" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on agencies" ON "public"."agencies" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on agency_plans" ON "public"."agency_plans" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on bookings" ON "public"."bookings" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on contracts" ON "public"."contracts" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on jobs" ON "public"."jobs" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on notifications" ON "public"."notifications" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on profiles" ON "public"."profiles" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on submissions" ON "public"."submissions" USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access on talent_profiles" ON "public"."talent_profiles" USING (true) WITH CHECK (true);



CREATE POLICY "Users can read own notifications" ON "public"."notifications" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can read own profile" ON "public"."profiles" FOR SELECT USING (("auth"."uid"() = "id"));



CREATE POLICY "Users can read own terms acceptance" ON "public"."terms_acceptances" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update own notifications" ON "public"."notifications" FOR UPDATE USING (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."admin_audit_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."admin_notification_broadcasts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."agencies" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."agency_plans" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."agency_talent_history" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."asaas_webhook_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."backup_test_payments_20260501" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."backup_test_wallet_transactions_20260501" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."bookings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."contracts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deny_client_delete_wallet_transactions" ON "public"."wallet_transactions" AS RESTRICTIVE FOR DELETE TO "authenticated" USING (false);



CREATE POLICY "deny_client_insert_wallet_transactions" ON "public"."wallet_transactions" AS RESTRICTIVE FOR INSERT TO "authenticated" WITH CHECK (false);



CREATE POLICY "deny_client_update_wallet_transactions" ON "public"."wallet_transactions" AS RESTRICTIVE FOR UPDATE TO "authenticated" USING (false);



CREATE POLICY "jil_workspace_member_select" ON "public"."job_invite_links" FOR SELECT USING ((("workspace_id" IS NOT NULL) AND ("workspace_id" IN ( SELECT "premium_workspace_members"."workspace_id"
   FROM "public"."premium_workspace_members"
  WHERE (("premium_workspace_members"."user_id" = "auth"."uid"()) AND ("premium_workspace_members"."status" = 'active'::"text"))))));



ALTER TABLE "public"."job_invite_links" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."job_invites" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "job_invites_agency_manage_own" ON "public"."job_invites" TO "authenticated" USING (("agency_id" = "auth"."uid"())) WITH CHECK (("agency_id" = "auth"."uid"()));



CREATE POLICY "job_invites_talent_read_own" ON "public"."job_invites" FOR SELECT TO "authenticated" USING (("talent_id" = "auth"."uid"()));



ALTER TABLE "public"."jobs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."notifications" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "pai_workspace_owner_select" ON "public"."premium_agent_invites" FOR SELECT USING (("workspace_id" IN ( SELECT "premium_workspace_members"."workspace_id"
   FROM "public"."premium_workspace_members"
  WHERE (("premium_workspace_members"."user_id" = "auth"."uid"()) AND ("premium_workspace_members"."role" = 'owner'::"text") AND ("premium_workspace_members"."status" = 'active'::"text")))));



ALTER TABLE "public"."payments" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."plan_settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."plan_settings_history" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."platform_settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."premium_agent_invites" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."premium_agent_wallet_transactions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."premium_workspace_members" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."premium_workspace_talents" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."premium_workspaces" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "profiles_insert" ON "public"."profiles" FOR INSERT WITH CHECK (("auth"."uid"() = "id"));



CREATE POLICY "profiles_select" ON "public"."profiles" FOR SELECT USING (("auth"."uid"() = "id"));



CREATE POLICY "profiles_update" ON "public"."profiles" FOR UPDATE USING (("auth"."uid"() = "id"));



CREATE POLICY "pw_member_select" ON "public"."premium_workspaces" FOR SELECT USING (("id" IN ( SELECT "premium_workspace_members"."workspace_id"
   FROM "public"."premium_workspace_members"
  WHERE (("premium_workspace_members"."user_id" = "auth"."uid"()) AND ("premium_workspace_members"."status" = 'active'::"text")))));



CREATE POLICY "pwm_self_select" ON "public"."premium_workspace_members" FOR SELECT USING (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."referral_invites" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "referral_invites_referrer_select" ON "public"."referral_invites" FOR SELECT USING (("auth"."uid"() = "referrer_id"));



ALTER TABLE "public"."saved_cards" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "saved_cards_delete_own" ON "public"."saved_cards" FOR DELETE TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "saved_cards_select_own" ON "public"."saved_cards" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "service_role_only" ON "public"."admin_notification_broadcasts" USING (false) WITH CHECK (false);



CREATE POLICY "service_role_only" ON "public"."plan_settings_history" USING (false) WITH CHECK (false);



ALTER TABLE "public"."stripe_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."submissions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "support_conv_own" ON "public"."support_conversations" USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."support_conversations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."support_messages" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "support_msg_insert_own" ON "public"."support_messages" FOR INSERT WITH CHECK ((("sender_id" = "auth"."uid"()) AND ("sender_role" = 'user'::"text") AND ("conversation_id" IN ( SELECT "support_conversations"."id"
   FROM "public"."support_conversations"
  WHERE ("support_conversations"."user_id" = "auth"."uid"())))));



CREATE POLICY "support_msg_read_own" ON "public"."support_messages" FOR SELECT USING (("conversation_id" IN ( SELECT "support_conversations"."id"
   FROM "public"."support_conversations"
  WHERE ("support_conversations"."user_id" = "auth"."uid"()))));



ALTER TABLE "public"."talent_availability" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "talent_availability_manage_own" ON "public"."talent_availability" TO "authenticated" USING (("talent_id" = "auth"."uid"())) WITH CHECK (("talent_id" = "auth"."uid"()));



ALTER TABLE "public"."talent_profiles" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."terms_acceptances" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."wallet_funding_sources" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."wallet_transactions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "wallet_transactions_select_own" ON "public"."wallet_transactions" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."wallet_withdrawal_source_allocations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."webhook_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "Anyone can read talent-media" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'talent-media'::"text"));



CREATE POLICY "Authenticated users can update talent-media" ON "storage"."objects" FOR UPDATE USING ((("bucket_id" = 'talent-media'::"text") AND ("auth"."role"() = 'authenticated'::"text")));



CREATE POLICY "Authenticated users can upload to talent-media" ON "storage"."objects" FOR INSERT WITH CHECK ((("bucket_id" = 'talent-media'::"text") AND ("auth"."role"() = 'authenticated'::"text")));



CREATE POLICY "Public read" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'avatars'::"text"));



CREATE POLICY "Public upload" ON "storage"."objects" FOR INSERT WITH CHECK (("bucket_id" = 'avatars'::"text"));



CREATE POLICY "avatars read" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'avatars'::"text"));



CREATE POLICY "avatars upload" ON "storage"."objects" FOR INSERT WITH CHECK (("bucket_id" = 'avatars'::"text"));



ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "logos read" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'logos'::"text"));



CREATE POLICY "logos upload" ON "storage"."objects" FOR INSERT WITH CHECK (("bucket_id" = 'logos'::"text"));



ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "talent media read" ON "storage"."objects" FOR SELECT USING (("bucket_id" = 'talent-media'::"text"));



CREATE POLICY "talent media upload" ON "storage"."objects" FOR INSERT WITH CHECK (("bucket_id" = 'talent-media'::"text"));



ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;


GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";



GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";



GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";



GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";



GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";



GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."_set_updated_at_premium"() TO "anon";
GRANT ALL ON FUNCTION "public"."_set_updated_at_premium"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."_set_updated_at_premium"() TO "service_role";



GRANT ALL ON FUNCTION "public"."allocate_wallet_withdrawal_sources"("p_user_id" "uuid", "p_withdrawal_transaction_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."allocate_wallet_withdrawal_sources"("p_user_id" "uuid", "p_withdrawal_transaction_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."allocate_wallet_withdrawal_sources"("p_user_id" "uuid", "p_withdrawal_transaction_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."cancel_agency_withdrawal"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."cancel_agency_withdrawal"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."cancel_agency_withdrawal"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."cancel_contract_safe"("p_contract_id" "uuid", "p_agency_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."cancel_contract_safe"("p_contract_id" "uuid", "p_agency_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."cancel_contract_safe"("p_contract_id" "uuid", "p_agency_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."cancel_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."cancel_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."cancel_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."confirm_booking_escrow"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."confirm_booking_escrow"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."confirm_booking_escrow"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."confirm_contract_stripe_funding"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric, "p_payment_intent_id" "text", "p_charge_id" "text", "p_checkout_session_id" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."confirm_contract_stripe_funding"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric, "p_payment_intent_id" "text", "p_charge_id" "text", "p_checkout_session_id" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."confirm_contract_stripe_funding"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric, "p_payment_intent_id" "text", "p_charge_id" "text", "p_checkout_session_id" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."credit_referral_commission"("p_referrer_id" "uuid", "p_invite_id" "uuid", "p_contract_id" "uuid", "p_commission" numeric, "p_job_title" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."credit_referral_commission"("p_referrer_id" "uuid", "p_invite_id" "uuid", "p_contract_id" "uuid", "p_commission" numeric, "p_job_title" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."credit_referral_commission"("p_referrer_id" "uuid", "p_invite_id" "uuid", "p_contract_id" "uuid", "p_commission" numeric, "p_job_title" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."credit_stripe_wallet_deposit"("p_user_id" "uuid", "p_transaction_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."credit_stripe_wallet_deposit"("p_user_id" "uuid", "p_transaction_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."credit_stripe_wallet_deposit"("p_user_id" "uuid", "p_transaction_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."credit_wallet_deposit"("p_user_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."credit_wallet_deposit"("p_user_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."credit_wallet_deposit"("p_user_id" "uuid", "p_payment_id" "text", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."fail_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text", "p_provider_status" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fail_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text", "p_provider_status" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fail_wallet_withdrawal"("p_transaction_id" "uuid", "p_reason" "text", "p_provider_status" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."finalize_contract_platform_revenue"("p_contract_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."finalize_contract_platform_revenue"("p_contract_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."finalize_contract_platform_revenue"("p_contract_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_auto_withdrawable_balance"("p_user_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."get_auto_withdrawable_balance"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auto_withdrawable_balance"("p_user_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."increment_wallet_balance"("p_user_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."increment_wallet_balance"("p_user_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."increment_wallet_balance"("p_user_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."mark_agency_withdrawal_paid"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."mark_agency_withdrawal_paid"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."mark_agency_withdrawal_paid"("p_tx_id" "uuid", "p_admin_id" "uuid", "p_note" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."mark_wallet_withdrawal_paid"("p_transaction_id" "uuid", "p_provider" "text", "p_admin_note" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."mark_wallet_withdrawal_paid"("p_transaction_id" "uuid", "p_provider" "text", "p_admin_note" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."mark_wallet_withdrawal_paid"("p_transaction_id" "uuid", "p_provider" "text", "p_admin_note" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."prevent_privilege_escalation"() TO "anon";
GRANT ALL ON FUNCTION "public"."prevent_privilege_escalation"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."prevent_privilege_escalation"() TO "service_role";



GRANT ALL ON FUNCTION "public"."register_wallet_funding_source"("p_user_id" "uuid", "p_source_wallet_transaction_id" "uuid", "p_stripe_charge_id" "text", "p_stripe_payment_intent_id" "text", "p_source_type" "text", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."register_wallet_funding_source"("p_user_id" "uuid", "p_source_wallet_transaction_id" "uuid", "p_stripe_charge_id" "text", "p_stripe_payment_intent_id" "text", "p_source_type" "text", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."register_wallet_funding_source"("p_user_id" "uuid", "p_source_wallet_transaction_id" "uuid", "p_stripe_charge_id" "text", "p_stripe_payment_intent_id" "text", "p_source_type" "text", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."release_payment_payout"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."release_payment_payout"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."release_payment_payout"("p_contract_id" "uuid", "p_agency_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."request_agency_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_fee_rate" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."request_agency_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_fee_rate" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."request_agency_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_fee_rate" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."request_talent_withdrawal"("p_user_id" "uuid", "p_amount" numeric) TO "anon";
GRANT ALL ON FUNCTION "public"."request_talent_withdrawal"("p_user_id" "uuid", "p_amount" numeric) TO "authenticated";
GRANT ALL ON FUNCTION "public"."request_talent_withdrawal"("p_user_id" "uuid", "p_amount" numeric) TO "service_role";



GRANT ALL ON FUNCTION "public"."request_wallet_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_kind" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."request_wallet_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_kind" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."request_wallet_withdrawal"("p_user_id" "uuid", "p_amount" numeric, "p_kind" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."restore_wallet_withdrawal_sources"("p_withdrawal_transaction_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."restore_wallet_withdrawal_sources"("p_withdrawal_transaction_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."restore_wallet_withdrawal_sources"("p_withdrawal_transaction_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."set_payments_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_payments_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_payments_updated_at"() TO "service_role";



GRANT ALL ON FUNCTION "public"."sync_agency_talent_history"() TO "anon";
GRANT ALL ON FUNCTION "public"."sync_agency_talent_history"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."sync_agency_talent_history"() TO "service_role";



GRANT ALL ON FUNCTION "public"."sync_booking_on_contract_update"() TO "anon";
GRANT ALL ON FUNCTION "public"."sync_booking_on_contract_update"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."sync_booking_on_contract_update"() TO "service_role";



GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;



GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;



GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";



GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";



GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;



GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";



GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";



GRANT ALL ON TABLE "public"."admin_audit_logs" TO "anon";
GRANT ALL ON TABLE "public"."admin_audit_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."admin_audit_logs" TO "service_role";



GRANT ALL ON TABLE "public"."admin_notification_broadcasts" TO "anon";
GRANT ALL ON TABLE "public"."admin_notification_broadcasts" TO "authenticated";
GRANT ALL ON TABLE "public"."admin_notification_broadcasts" TO "service_role";



GRANT ALL ON TABLE "public"."agencies" TO "anon";
GRANT ALL ON TABLE "public"."agencies" TO "authenticated";
GRANT ALL ON TABLE "public"."agencies" TO "service_role";



GRANT ALL ON TABLE "public"."agency_plans" TO "anon";
GRANT ALL ON TABLE "public"."agency_plans" TO "authenticated";
GRANT ALL ON TABLE "public"."agency_plans" TO "service_role";



GRANT ALL ON TABLE "public"."agency_talent_history" TO "anon";
GRANT ALL ON TABLE "public"."agency_talent_history" TO "authenticated";
GRANT ALL ON TABLE "public"."agency_talent_history" TO "service_role";



GRANT ALL ON TABLE "public"."applications" TO "anon";
GRANT ALL ON TABLE "public"."applications" TO "authenticated";
GRANT ALL ON TABLE "public"."applications" TO "service_role";



GRANT ALL ON TABLE "public"."asaas_webhook_events" TO "anon";
GRANT ALL ON TABLE "public"."asaas_webhook_events" TO "authenticated";
GRANT ALL ON TABLE "public"."asaas_webhook_events" TO "service_role";



GRANT ALL ON TABLE "public"."backup_test_payments_20260501" TO "anon";
GRANT ALL ON TABLE "public"."backup_test_payments_20260501" TO "authenticated";
GRANT ALL ON TABLE "public"."backup_test_payments_20260501" TO "service_role";



GRANT ALL ON TABLE "public"."backup_test_wallet_transactions_20260501" TO "anon";
GRANT ALL ON TABLE "public"."backup_test_wallet_transactions_20260501" TO "authenticated";
GRANT ALL ON TABLE "public"."backup_test_wallet_transactions_20260501" TO "service_role";



GRANT ALL ON TABLE "public"."bookings" TO "anon";
GRANT ALL ON TABLE "public"."bookings" TO "authenticated";
GRANT ALL ON TABLE "public"."bookings" TO "service_role";



GRANT ALL ON TABLE "public"."contracts" TO "anon";
GRANT ALL ON TABLE "public"."contracts" TO "authenticated";
GRANT ALL ON TABLE "public"."contracts" TO "service_role";



GRANT ALL ON TABLE "public"."job_invite_links" TO "anon";
GRANT ALL ON TABLE "public"."job_invite_links" TO "authenticated";
GRANT ALL ON TABLE "public"."job_invite_links" TO "service_role";



GRANT ALL ON TABLE "public"."job_invites" TO "anon";
GRANT ALL ON TABLE "public"."job_invites" TO "authenticated";
GRANT ALL ON TABLE "public"."job_invites" TO "service_role";



GRANT ALL ON TABLE "public"."jobs" TO "anon";
GRANT ALL ON TABLE "public"."jobs" TO "authenticated";
GRANT ALL ON TABLE "public"."jobs" TO "service_role";



GRANT ALL ON TABLE "public"."notifications" TO "anon";
GRANT ALL ON TABLE "public"."notifications" TO "authenticated";
GRANT ALL ON TABLE "public"."notifications" TO "service_role";



GRANT ALL ON TABLE "public"."payments" TO "anon";
GRANT ALL ON TABLE "public"."payments" TO "authenticated";
GRANT ALL ON TABLE "public"."payments" TO "service_role";



GRANT ALL ON TABLE "public"."plan_settings" TO "anon";
GRANT ALL ON TABLE "public"."plan_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."plan_settings" TO "service_role";



GRANT ALL ON TABLE "public"."plan_settings_history" TO "anon";
GRANT ALL ON TABLE "public"."plan_settings_history" TO "authenticated";
GRANT ALL ON TABLE "public"."plan_settings_history" TO "service_role";



GRANT ALL ON TABLE "public"."platform_balance" TO "anon";
GRANT ALL ON TABLE "public"."platform_balance" TO "authenticated";
GRANT ALL ON TABLE "public"."platform_balance" TO "service_role";



GRANT ALL ON TABLE "public"."platform_settings" TO "anon";
GRANT ALL ON TABLE "public"."platform_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."platform_settings" TO "service_role";



GRANT ALL ON TABLE "public"."premium_agent_invites" TO "anon";
GRANT ALL ON TABLE "public"."premium_agent_invites" TO "authenticated";
GRANT ALL ON TABLE "public"."premium_agent_invites" TO "service_role";



GRANT ALL ON TABLE "public"."premium_agent_wallet_transactions" TO "anon";
GRANT ALL ON TABLE "public"."premium_agent_wallet_transactions" TO "authenticated";
GRANT ALL ON TABLE "public"."premium_agent_wallet_transactions" TO "service_role";



GRANT ALL ON TABLE "public"."premium_workspace_members" TO "anon";
GRANT ALL ON TABLE "public"."premium_workspace_members" TO "authenticated";
GRANT ALL ON TABLE "public"."premium_workspace_members" TO "service_role";



GRANT ALL ON TABLE "public"."premium_workspace_talents" TO "anon";
GRANT ALL ON TABLE "public"."premium_workspace_talents" TO "authenticated";
GRANT ALL ON TABLE "public"."premium_workspace_talents" TO "service_role";



GRANT ALL ON TABLE "public"."premium_workspaces" TO "anon";
GRANT ALL ON TABLE "public"."premium_workspaces" TO "authenticated";
GRANT ALL ON TABLE "public"."premium_workspaces" TO "service_role";



GRANT ALL ON TABLE "public"."profiles" TO "anon";
GRANT ALL ON TABLE "public"."profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."profiles" TO "service_role";



GRANT ALL ON TABLE "public"."referral_invites" TO "anon";
GRANT ALL ON TABLE "public"."referral_invites" TO "authenticated";
GRANT ALL ON TABLE "public"."referral_invites" TO "service_role";



GRANT ALL ON TABLE "public"."saved_cards" TO "anon";
GRANT ALL ON TABLE "public"."saved_cards" TO "authenticated";
GRANT ALL ON TABLE "public"."saved_cards" TO "service_role";



GRANT ALL ON TABLE "public"."stripe_events" TO "anon";
GRANT ALL ON TABLE "public"."stripe_events" TO "authenticated";
GRANT ALL ON TABLE "public"."stripe_events" TO "service_role";



GRANT ALL ON TABLE "public"."submissions" TO "anon";
GRANT ALL ON TABLE "public"."submissions" TO "authenticated";
GRANT ALL ON TABLE "public"."submissions" TO "service_role";



GRANT ALL ON TABLE "public"."support_conversations" TO "anon";
GRANT ALL ON TABLE "public"."support_conversations" TO "authenticated";
GRANT ALL ON TABLE "public"."support_conversations" TO "service_role";



GRANT ALL ON TABLE "public"."support_messages" TO "anon";
GRANT ALL ON TABLE "public"."support_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."support_messages" TO "service_role";



GRANT ALL ON TABLE "public"."talent_availability" TO "anon";
GRANT ALL ON TABLE "public"."talent_availability" TO "authenticated";
GRANT ALL ON TABLE "public"."talent_availability" TO "service_role";



GRANT ALL ON TABLE "public"."talent_profiles" TO "anon";
GRANT ALL ON TABLE "public"."talent_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."talent_profiles" TO "service_role";



GRANT ALL ON TABLE "public"."terms_acceptances" TO "anon";
GRANT ALL ON TABLE "public"."terms_acceptances" TO "authenticated";
GRANT ALL ON TABLE "public"."terms_acceptances" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_funding_sources" TO "anon";
GRANT ALL ON TABLE "public"."wallet_funding_sources" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_funding_sources" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_transactions" TO "anon";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_withdrawal_source_allocations" TO "anon";
GRANT ALL ON TABLE "public"."wallet_withdrawal_source_allocations" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_withdrawal_source_allocations" TO "service_role";



GRANT ALL ON TABLE "public"."webhook_events" TO "anon";
GRANT ALL ON TABLE "public"."webhook_events" TO "authenticated";
GRANT ALL ON TABLE "public"."webhook_events" TO "service_role";



REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;



GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";



GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";



REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;



GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";



GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";



GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";



ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";



ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";



ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";




